#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
import os
import sys


# Funzione principale per eseguire i comandi di amministrazione di Django
def main():
    """Run administrative tasks."""
    # Imposta il modulo delle impostazioni Django da usare
    os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'myapp.settings')
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:
        raise ImportError(
            "Couldn't import Django. Are you sure it's installed and "
            "available on your PYTHONPATH environment variable? Did you "
            "forget to activate a virtual environment?"
        ) from exc
    execute_from_command_line(sys.argv)


# Esecuzione dello script solo se lanciato direttamente
if __name__ == '__main__':
    main()