"""
Django settings for myapp project.
"""

import os
from pathlib import Path

# Percorso assoluto alla cartella principale del progetto
BASE_DIR = Path(__file__).resolve().parent.parent

# Chiave segreta per la sicurezza di Django (in produzione va nascosta)
SECRET_KEY = 'django-insecure-tc12%m!9-9-5ntoglaun6i-wmk@b%l_1o4)*h6#d#^j*%vbrj('

# Modalita debug attiva (in produzione va impostata su False)
DEBUG = True

# Host consentiti per l'esecuzione del sito (asterisco = tutti)
ALLOWED_HOSTS = ['*']


# Applicazioni Django installate
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
]

# Middleware abilitati per la gestione di sicurezza, sessioni, CSRF, auth e messaggi
MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

# Modulo principale per la configurazione degli URL
ROOT_URLCONF = 'myapp.urls'

# Configurazione del motore dei template Django
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        # Percorso globale per la cartella dei template HTML
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

# Punto di ingresso per il server WSGI
WSGI_APPLICATION = 'myapp.wsgi.application'


# Database relazionale interno di Django (usato solo per sessioni e admin)
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}


# Validazione delle password degli utenti
AUTH_PASSWORD_VALIDATORS = [
    {
        'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator',
    },
    {
        'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator',
    },
]


# Impostazioni di localizzazione e fuso orario
LANGUAGE_CODE = 'it-it'

TIME_ZONE = 'Europe/Rome'

USE_I18N = True

USE_TZ = True


# Percorso per i file statici (CSS, JS, immagini)
STATIC_URL = 'static/'
STATICFILES_DIRS = [BASE_DIR / 'static']


# Configurazione MongoDB letta da variabili d'ambiente
# Cosi si puo scegliere porta e nome del database al momento del deploy
# senza dover modificare questo file
MONGO_HOST = os.environ.get('MONGO_HOST', 'localhost')
MONGO_PORT = int(os.environ.get('MONGO_PORT', '27017'))
MONGO_DB_NAME = os.environ.get('MONGO_DB_NAME', 'PW26_Database')


# Tipo di campo per le chiavi primarie auto-generate
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'