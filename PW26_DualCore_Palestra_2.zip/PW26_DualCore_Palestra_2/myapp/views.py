from datetime import datetime, date
import re
from django.conf import settings
from django.shortcuts import render, redirect
from pymongo import MongoClient


# Connessione a MongoDB usando le impostazioni definite in settings.py
def get_db():
    client = MongoClient(f"mongodb://{settings.MONGO_HOST}:{settings.MONGO_PORT}/")
    return client, client[settings.MONGO_DB_NAME]


# Converte una stringa in data, supportando diversi formati (YYYY-MM-DD, DD/MM/YYYY, ecc.)
def parse_date_multi(value):
    if value is None:
        return None
    value = str(value).strip()
    if not value:
        return None
    for fmt in ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y", "%Y/%m/%d"):
        try:
            return datetime.strptime(value, fmt).date()
        except ValueError:
            pass
    return None


# Formatta una data nel formato italiano GG/MM/AAAA
def fmt_data_it(value):
    d = parse_date_multi(value)
    return d.strftime('%d/%m/%Y') if d else (value or '')


# Converte una data in formato GG/MM/AAAA per interrogare MongoDB
def fmt_data_db(value):
    d = parse_date_multi(value)
    return d.strftime('%d/%m/%Y') if d else ''


# Converte un valore in intero, restituendo un default se fallisce
def parse_int(value, default=None):
    try:
        return int(str(value).strip())
    except Exception:
        return default


# Converte un valore in numero decimale, restituendo un default se fallisce
def parse_float(value, default=0.0):
    try:
        return float(str(value).replace(',', '.').strip())
    except Exception:
        return default


# Formatta un prezzo in stile italiano, esempio 219,90
def fmt_prezzo(value):
    return f"{parse_float(value):.2f}".replace('.', ',')


# Verifica che nome o cognome contengano solo lettere, spazi, apostrofi e trattini
def nome_cognome_valido(testo):
    testo = (testo or '').strip()
    if not testo:
        return False
    return re.match(r"^[A-Za-zÀ-ÖØ-öø-ÿ]+(?:[ '\-][A-Za-zÀ-ÖØ-öø-ÿ]+)*$", testo) is not None


# Formatta un numero di telefono nel formato +39 XXX XXX XXXX, restituendo False se non valido
def formatta_telefono(telefono):
    solo_numeri = re.sub(r'\D+', '', telefono or '')
    if solo_numeri.startswith('0039'):
        solo_numeri = solo_numeri[4:]
    if solo_numeri.startswith('39') and len(solo_numeri) == 12:
        solo_numeri = solo_numeri[2:]
    if not re.match(r'^3\d{9}$', solo_numeri):
        return False
    return f"+39 {solo_numeri[0:3]} {solo_numeri[3:6]} {solo_numeri[6:10]}"


# Normalizza un indirizzo nel formato standard: Via Roma, 15, 20100 Milano
def normalizza_indirizzo(indirizzo):
    indirizzo = (indirizzo or '').strip()
    if not indirizzo:
        return ''
    parti = [p.strip() for p in indirizzo.split(',')]
    if len(parti) != 3:
        return re.sub(r'\s+', ' ', indirizzo)
    via_comune = re.sub(r'\s+', ' ', parti[0])
    civico = re.sub(r'\s+', '', parti[1])
    cap_comune = re.sub(r'\s+', ' ', parti[2])
    return f"{via_comune}, {civico}, {cap_comune}"


# Verifica che un indirizzo rispetti il formato corretto usando un'espressione regolare
def indirizzo_valido(indirizzo):
    indirizzo = normalizza_indirizzo(indirizzo)
    pattern = r"^.+,\s*\d+[A-Za-z]?(?:[\/-][A-Za-z0-9]+)?,\s*\d{5}\s+[A-Za-zÀ-ÖØ-öø-ÿ'\-\s]+$"
    return re.match(pattern, indirizzo.strip()) is not None


# Calcola l'eta in anni compiuti a partire da una data ISO (AAAA-MM-GG)
def calcola_eta(data_nascita_iso):
    nascita = parse_date_multi(data_nascita_iso)
    if not nascita:
        return None
    oggi = date.today()
    eta = oggi.year - nascita.year
    if (oggi.month, oggi.day) < (nascita.month, nascita.day):
        eta -= 1
    return eta


# Genera il prossimo codice cliente disponibile (massimo + 1)
def next_cliente_code(db):
    docs = list(db['Cliente'].find({}, {'codice': 1, '_id': 0}))
    codes = [parse_int(d.get('codice')) for d in docs]
    codes = [c for c in codes if c is not None]
    return (max(codes) + 1) if codes else 1


# Calcola lo stato di un abbonamento in base alle date di inizio e fine
def stato_abbonamento(inizio, fine, oggi):
    d_inizio = parse_date_multi(inizio)
    d_fine = parse_date_multi(fine)
    if d_inizio and oggi < d_inizio:
        return 'Futuro'
    if d_inizio and d_fine and d_inizio <= oggi <= d_fine:
        return 'Attivo'
    return 'Scaduto'


# Crea una mappa prenotazione -> abbonamento a partire da SubAbbonamento
def build_sub_map(db):
    mappa = {}
    for x in db['SubAbbonamento'].find({}, {'_id': 0}):
        mappa[str(x.get('prenotazione'))] = x.get('abbonamento')
    return mappa


# Calcola il numero di pagine e la lista di numeri da mostrare in paginazione
def calcola_pagine(totale, per_pagina, pagina):
    totale_pagine = max(1, (totale + per_pagina - 1) // per_pagina)
    pagina = max(1, min(pagina, totale_pagine))
    pages = list(range(max(1, pagina - 2), min(totale_pagine, pagina + 2) + 1))
    return pagina, totale_pagine, pages


# Pagina Home: va direttamente alla lista clienti, come nel progetto PHP
def home(request):
    return redirect('/clienti/')


# Lista clienti con ricerca su piu campi, paginazione e messaggi di stato
def clienti_lista(request):
    record_per_pagina = 20
    pagina = max(1, parse_int(request.GET.get('pagina'), 1) or 1)
    nome = (request.GET.get('nome') or '').strip()
    cognome = (request.GET.get('cognome') or '').strip()
    cf = (request.GET.get('cf') or '').strip()
    tel = (request.GET.get('tel') or '').strip()
    filtri_attivi = bool(nome or cognome or cf or tel)

    messaggio = ''
    if request.GET.get('creato'):
        messaggio = 'Cliente creato correttamente.'
    elif request.GET.get('aggiornato'):
        messaggio = 'Cliente aggiornato correttamente.'
    elif request.GET.get('eliminato'):
        messaggio = 'Cliente eliminato correttamente.'

    errore = ''
    clienti = []
    totale_clienti = 0
    totale_pagine = 1
    pages = [1]

    client, db = get_db()
    try:
        all_clienti = list(db['Cliente'].find({}, {'_id': 0}))
        if nome:
            r = nome.lower()
            all_clienti = [c for c in all_clienti if r in str(c.get('nome', '')).lower()]
        if cognome:
            r = cognome.lower()
            all_clienti = [c for c in all_clienti if r in str(c.get('cognome', '')).lower()]
        if cf:
            r = cf.lower()
            all_clienti = [c for c in all_clienti if r in str(c.get('cf', '')).lower()]
        if tel:
            r = tel.lower()
            all_clienti = [c for c in all_clienti if r in str(c.get('tel', '')).lower()]

        all_clienti.sort(key=lambda c: (str(c.get('cognome', '')).lower(), str(c.get('nome', '')).lower(), parse_int(c.get('codice'), 0) or 0))
        totale_clienti = len(all_clienti)
        pagina, totale_pagine, pages = calcola_pagine(totale_clienti, record_per_pagina, pagina)
        offset = (pagina - 1) * record_per_pagina
        clienti = all_clienti[offset:offset + record_per_pagina]
        for c in clienti:
            c['dataNas_fmt'] = fmt_data_it(c.get('dataNas'))
    except Exception:
        errore = "Non e stato possibile recuperare l'elenco dei clienti."
    finally:
        client.close()

    return render(request, 'clienti.html', {'clienti': clienti, 'totaleClienti': totale_clienti, 'totalePagine': totale_pagine, 'pagina': pagina, 'pages': pages, 'nome': nome, 'cognome': cognome, 'cf': cf, 'tel': tel, 'filtriAttivi': filtri_attivi, 'messaggio': messaggio, 'errore': errore})


# Dettaglio di un singolo cliente con abbonamenti e prenotazioni
def cliente_dettaglio(request):
    codice = (request.GET.get('codice') or '').strip()
    if not codice:
        return redirect('/clienti/')
    errore = ''
    cliente_doc = None
    abbonamenti = []
    prenotazioni = []
    client, db = get_db()
    try:
        cliente_doc = db['Cliente'].find_one({'codice': codice}, {'_id': 0}) or db['Cliente'].find_one({'codice': parse_int(codice, -1)}, {'_id': 0})
        if not cliente_doc:
            return redirect('/clienti/')
        oggi = date.today()

        abb = list(db['Abbonamento'].find({'cliente': {'$in': [codice, parse_int(codice, -1)]}}, {'_id': 0}))
        abb.sort(key=lambda a: parse_date_multi(a.get('inizio')) or date.min, reverse=True)
        for a in abb:
            a['inizio_fmt'] = fmt_data_it(a.get('inizio'))
            a['fine_fmt'] = fmt_data_it(a.get('fine'))
            a['stato'] = stato_abbonamento(a.get('inizio'), a.get('fine'), oggi)
            a['prezzo_fmt'] = fmt_prezzo(a.get('prezzo'))
        abbonamenti = abb

        sale_map = {str(s.get('codice')): s for s in db['Sala'].find({}, {'_id': 0})}
        sub_map = build_sub_map(db)

        prs = list(db['Prenotazione'].find({'cliente': {'$in': [codice, parse_int(codice, -1)]}}, {'_id': 0}))
        prs.sort(key=lambda p: (parse_date_multi(p.get('data')) or date.min, str(p.get('ora', ''))), reverse=True)
        for p in prs:
            sala = sale_map.get(str(p.get('sala')), {})
            numero_abbonamento = sub_map.get(str(p.get('nProg')))
            p['sala_nome'] = sala.get('nome', '')
            p['sala_codice'] = p.get('sala')
            p['tipo'] = 'Sub Abbonamento' if numero_abbonamento else 'Semplice'
            p['numero_abbonamento'] = numero_abbonamento
            p['data_fmt'] = fmt_data_it(p.get('data'))
            p['ora_fmt'] = str(p.get('ora', ''))[:5]
        prenotazioni = prs

        cliente_doc['dataNas_fmt'] = fmt_data_it(cliente_doc.get('dataNas'))
    except Exception:
        errore = 'Errore nel caricamento dei dati. Riprova piu tardi.'
    finally:
        client.close()
    return render(request, 'cliente_dettaglio.html', {'codice': codice, 'cliente': cliente_doc, 'abbonamenti': abbonamenti, 'prenotazioni': prenotazioni, 'errore': errore})


# Form per creare o modificare un cliente con validazione completa dei campi
def cliente_form(request):
    codice = (request.GET.get('codice') or request.POST.get('codice') or '').strip()
    modifica = codice != ''
    valori = {'nome': '', 'cognome': '', 'cf': '', 'dataNas': '', 'indirizzo': '', 'tel': '', 'email': ''}
    errori_campi = {}
    errore = ''
    oggi_iso = date.today().strftime('%Y-%m-%d')

    client, db = get_db()
    try:
        if modifica and request.method == 'GET':
            row = db['Cliente'].find_one({'codice': codice}, {'_id': 0}) or db['Cliente'].find_one({'codice': parse_int(codice, -1)}, {'_id': 0})
            if not row:
                client.close()
                return redirect('/clienti/')
            data_nas = parse_date_multi(row.get('dataNas'))
            valori = {
                'nome': row.get('nome', ''),
                'cognome': row.get('cognome', ''),
                'cf': row.get('cf', ''),
                'dataNas': data_nas.strftime('%Y-%m-%d') if data_nas else '',
                'indirizzo': row.get('indirizzo', ''),
                'tel': row.get('tel', ''),
                'email': row.get('email', ''),
            }

        if request.method == 'POST':
            for campo in valori.keys():
                valori[campo] = (request.POST.get(campo) or '').strip()

            if valori['nome'] == '':
                errori_campi['nome'] = 'Il nome e obbligatorio.'
            elif not nome_cognome_valido(valori['nome']):
                errori_campi['nome'] = 'Il nome puo contenere solo lettere, spazi, apostrofi e trattini.'

            if valori['cognome'] == '':
                errori_campi['cognome'] = 'Il cognome e obbligatorio.'
            elif not nome_cognome_valido(valori['cognome']):
                errori_campi['cognome'] = 'Il cognome puo contenere solo lettere, spazi, apostrofi e trattini.'

            if valori['cf'] == '':
                errori_campi['cf'] = 'Il codice fiscale e obbligatorio.'
            elif len(valori['cf']) != 16:
                errori_campi['cf'] = 'Il codice fiscale deve essere di 16 caratteri.'

            d = parse_date_multi(valori['dataNas'])
            if valori['dataNas'] == '' or d is None or d.strftime('%Y-%m-%d') != valori['dataNas']:
                errori_campi['dataNas'] = 'Inserire una data di nascita valida.'
            elif d > date.today():
                errori_campi['dataNas'] = 'La data di nascita non puo essere futura.'
            else:
                eta = calcola_eta(valori['dataNas'])
                if eta is None or eta < 18:
                    errori_campi['dataNas'] = 'Il cliente deve avere almeno 18 anni.'

            if valori['indirizzo'] == '':
                errori_campi['indirizzo'] = "L'indirizzo e obbligatorio."
            else:
                indirizzo_normalizzato = normalizza_indirizzo(valori['indirizzo'])
                if not indirizzo_valido(indirizzo_normalizzato):
                    errori_campi['indirizzo'] = 'Inserire un indirizzo nel formato corretto, ad esempio: Via Roma, 15, 20100 Milano.'
                else:
                    valori['indirizzo'] = indirizzo_normalizzato

            telefono_formattato = formatta_telefono(valori['tel'])
            if valori['tel'] == '':
                errori_campi['tel'] = 'Il numero di telefono e obbligatorio.'
            elif telefono_formattato is False:
                errori_campi['tel'] = 'Inserire un cellulare italiano valido. Esempio: +39 333 333 6666.'
            else:
                valori['tel'] = telefono_formattato

            if valori['email'] == '' or '@' not in valori['email']:
                errori_campi['email'] = 'Inserire un indirizzo email valido.'

            cf_upper = valori['cf'].upper()
            if not errori_campi:
                existing = list(db['Cliente'].find({'cf': cf_upper}, {'_id': 0}))
                if modifica:
                    existing = [e for e in existing if str(e.get('codice')) != str(codice)]
                if existing:
                    errore = 'Esiste gia un cliente con questo codice fiscale.'
                else:
                    doc = {'nome': valori['nome'], 'cognome': valori['cognome'], 'cf': cf_upper, 'dataNas': valori['dataNas'], 'indirizzo': valori['indirizzo'], 'tel': valori['tel'], 'email': valori['email']}
                    if modifica:
                        db['Cliente'].update_one({'codice': {'$in': [codice, parse_int(codice, -1)]}}, {'$set': doc})
                        client.close()
                        return redirect('/clienti/?aggiornato=1')
                    else:
                        doc['codice'] = str(next_cliente_code(db))
                        db['Cliente'].insert_one(doc)
                        client.close()
                        return redirect('/clienti/?creato=1')
    finally:
        client.close()
    return render(request, 'cliente_form.html', {'codice': codice, 'modifica': modifica, 'valori': valori, 'erroriCampi': errori_campi, 'errore': errore, 'oggi_iso': oggi_iso})


# Eliminazione di un cliente con cancellazione a cascata di abbonamenti e prenotazioni
def cliente_elimina(request):
    codice = (request.GET.get('codice') or request.POST.get('codice') or '').strip()
    if not codice:
        return redirect('/clienti/')
    cliente_doc = None
    num_abbonamenti = 0
    num_prenotazioni = 0
    errore = ''
    client, db = get_db()
    try:
        cliente_doc = db['Cliente'].find_one({'codice': codice}, {'_id': 0}) or db['Cliente'].find_one({'codice': parse_int(codice, -1)}, {'_id': 0})
        if not cliente_doc:
            client.close()
            return redirect('/clienti/')
        num_abbonamenti = db['Abbonamento'].count_documents({'cliente': {'$in': [codice, parse_int(codice, -1)]}})
        num_prenotazioni = db['Prenotazione'].count_documents({'cliente': {'$in': [codice, parse_int(codice, -1)]}})
        if request.method == 'POST':
            pren_docs = list(db['Prenotazione'].find({'cliente': {'$in': [codice, parse_int(codice, -1)]}}, {'nProg': 1, '_id': 0}))
            nprogs = [d.get('nProg') for d in pren_docs]
            if nprogs:
                db['SubAbbonamento'].delete_many({'prenotazione': {'$in': nprogs}})
            abb_docs = list(db['Abbonamento'].find({'cliente': {'$in': [codice, parse_int(codice, -1)]}}, {'nAbb': 1, '_id': 0}))
            nabbs = [d.get('nAbb') for d in abb_docs]
            if nabbs:
                db['SubAbbonamento'].delete_many({'abbonamento': {'$in': nabbs}})
            db['Prenotazione'].delete_many({'cliente': {'$in': [codice, parse_int(codice, -1)]}})
            db['Abbonamento'].delete_many({'cliente': {'$in': [codice, parse_int(codice, -1)]}})
            db['Cliente'].delete_one({'codice': {'$in': [codice, parse_int(codice, -1)]}})
            client.close()
            return redirect('/clienti/?eliminato=1')
    except Exception:
        errore = 'Non e stato possibile eliminare il cliente. Riprova piu tardi.' if request.method == 'POST' else 'Errore nel caricamento dei dati del cliente.'
    finally:
        client.close()
    return render(request, 'cliente_elimina.html', {'codice': codice, 'cliente': cliente_doc, 'numAbbonamenti': num_abbonamenti, 'numPrenotazioni': num_prenotazioni, 'errore': errore})


# Lista delle sale con filtri per nome e tema
def sale_lista(request):
    nome = (request.GET.get('nome') or '').strip()
    tema = (request.GET.get('tema') or '').strip()
    sale = []
    temi_lista = []
    errore = ''
    client, db = get_db()
    try:
        raw_sale = list(db['Sala'].find({}, {'_id': 0}))
        temi_lista = sorted({str(s.get('tema')) for s in raw_sale if s.get('tema') not in [None, '']})
        fasce = list(db['FasciaOraria'].find({}, {'_id': 0}))
        pren = list(db['Prenotazione'].find({}, {'_id': 0}))
        for s in raw_sale:
            if nome and nome.lower() not in str(s.get('nome', '')).lower():
                continue
            if tema and str(s.get('tema', '')) != tema:
                continue
            codice = str(s.get('codice'))
            item = dict(s)
            item['num_fasce'] = sum(1 for f in fasce if str(f.get('sala')) == codice)
            item['num_prenotazioni'] = sum(1 for p in pren if str(p.get('sala')) == codice)
            sale.append(item)
        sale.sort(key=lambda s: str(s.get('nome', '')).lower())
    except Exception:
        errore = 'Errore durante la ricerca. Riprova piu tardi.'
    finally:
        client.close()
    return render(request, 'sale.html', {'sale': sale, 'tema': tema, 'nome': nome, 'temiLista': temi_lista, 'errore': errore})


# Dettaglio di una sala con fasce orarie paginate
def sala_dettaglio(request):
    codice = (request.GET.get('codice') or '').strip()
    if not codice or not codice.isdigit():
        return redirect('/sale/')

    righe_per_pagina = 20
    pagina = max(1, parse_int(request.GET.get('pagina'), 1) or 1)

    sala = None
    fasce = []
    errore = ''
    numero_fasce = 0
    numero_posti = 0
    numero_prenotazioni = 0
    totale_pagine = 1
    pages = [1]

    client, db = get_db()
    try:
        sala = db['Sala'].find_one({'codice': codice}, {'_id': 0}) or db['Sala'].find_one({'codice': parse_int(codice, -1)}, {'_id': 0})
        if not sala:
            client.close()
            return redirect('/sale/')

        codice_sala = str(sala.get('codice'))

        numero_fasce = db['FasciaOraria'].count_documents({'sala': {'$in': [codice_sala, parse_int(codice_sala, -1)]}})
        numero_posti = db['Posto'].count_documents({'sala': {'$in': [codice_sala, parse_int(codice_sala, -1)]}})
        numero_prenotazioni = db['Prenotazione'].count_documents({'sala': {'$in': [codice_sala, parse_int(codice_sala, -1)]}})

        pagina, totale_pagine, pages = calcola_pagine(numero_fasce, righe_per_pagina, pagina)
        offset = (pagina - 1) * righe_per_pagina

        fasce_raw = [f for f in db['FasciaOraria'].find({}, {'_id': 0}) if str(f.get('sala')) == codice_sala]
        fasce_raw.sort(key=lambda x: (parse_date_multi(x.get('data')) or date.min, x.get('ora', '')), reverse=True)
        fasce_pagina = fasce_raw[offset:offset + righe_per_pagina]

        posti_raw = [p for p in db['Posto'].find({}, {'_id': 0}) if str(p.get('sala')) == codice_sala]
        pren_raw = [p for p in db['Prenotazione'].find({}, {'_id': 0}) if str(p.get('sala')) == codice_sala]

        for f in fasce_pagina:
            data_f = str(f.get('data'))
            ora_f = str(f.get('ora'))
            posti_totali = sum(1 for po in posti_raw if str(po.get('data')) == data_f and str(po.get('ora')) == ora_f)
            posti_prenotati = sum(1 for pr in pren_raw if str(pr.get('data')) == data_f and str(pr.get('ora')) == ora_f)
            posti_disponibili = max(0, posti_totali - posti_prenotati)
            percentuale = round((posti_prenotati / posti_totali) * 100) if posti_totali > 0 else 0
            fasce.append({**f, 'data_fmt': fmt_data_it(f.get('data')), 'ora_fmt': str(f.get('ora', ''))[:5], 'posti_totali': posti_totali, 'posti_prenotati': posti_prenotati, 'posti_disponibili': posti_disponibili, 'percentuale': percentuale})
    except Exception:
        errore = 'Non e stato possibile caricare i dati della sala. Riprova piu tardi.'
    finally:
        client.close()

    return render(request, 'sala_dettaglio.html', {'sala': sala, 'fasce': fasce, 'errore': errore, 'numeroFasce': numero_fasce, 'numeroPosti': numero_posti, 'numeroPrenotazioni': numero_prenotazioni, 'pagina': pagina, 'numeroPagine': totale_pagine, 'pages': pages})


# Dettaglio di una fascia oraria con l'elenco dei posti
def fasciaoraria(request):
    codice_sala = (request.GET.get('sala') or '').strip()
    data_raw = (request.GET.get('data') or '').strip()
    ora_raw = (request.GET.get('ora') or '').strip()
    data_db = fmt_data_db(data_raw)

    if not codice_sala or not codice_sala.isdigit() or not data_db or not ora_raw:
        return redirect('/sale/')

    ora_cerca = ora_raw[:5]
    fascia = None
    posti = []
    errore = ''
    posti_totali = 0
    posti_occupati = 0
    posti_disponibili = 0

    client, db = get_db()
    try:
        sala = db['Sala'].find_one({'codice': {'$in': [codice_sala, parse_int(codice_sala, -1)]}}, {'_id': 0})
        fascia_raw = None
        for f in db['FasciaOraria'].find({}, {'_id': 0}):
            if str(f.get('sala')) == codice_sala and str(f.get('data')) == data_db and str(f.get('ora'))[:5] == ora_cerca:
                fascia_raw = f
                break

        if not fascia_raw or not sala:
            errore = 'La fascia oraria richiesta non e stata trovata.'
        else:
            fascia = {**fascia_raw, 'codice_sala': sala.get('codice'), 'nome_sala': sala.get('nome'), 'tema_sala': sala.get('tema'), 'mq_sala': sala.get('mq'), 'data_fmt': fmt_data_it(fascia_raw.get('data')), 'ora_fmt': str(fascia_raw.get('ora'))[:5]}

            clienti_map = {str(c.get('codice')): c for c in db['Cliente'].find({}, {'_id': 0})}
            sub_map = build_sub_map(db)

            posti_raw = [p for p in db['Posto'].find({}, {'_id': 0}) if str(p.get('sala')) == codice_sala and str(p.get('data')) == data_db and str(p.get('ora'))[:5] == ora_cerca]
            pren_raw = [p for p in db['Prenotazione'].find({}, {'_id': 0}) if str(p.get('sala')) == codice_sala and str(p.get('data')) == data_db and str(p.get('ora'))[:5] == ora_cerca]
            pren_map = {str(p.get('posto')): p for p in pren_raw}

            posti_totali = len(posti_raw)
            for po in sorted(posti_raw, key=lambda x: parse_int(x.get('nProg'), 0)):
                numero_posto = po.get('nProg')
                pr = pren_map.get(str(numero_posto))
                if pr:
                    posti_occupati += 1
                    cli = clienti_map.get(str(pr.get('cliente')), {})
                    numero_abbonamento = sub_map.get(str(pr.get('nProg')))
                    posti.append({
                        'sala': po.get('sala'), 'data': po.get('data'), 'ora': po.get('ora'), 'ora_fmt': ora_cerca,
                        'numero_posto': numero_posto, 'stato_posto': 'Occupato',
                        'numero_prenotazione': pr.get('nProg'), 'codice_cliente': pr.get('cliente'),
                        'nome_cliente': cli.get('nome', ''), 'cognome_cliente': cli.get('cognome', ''),
                        'numero_abbonamento': numero_abbonamento,
                        'tipo_prenotazione': 'Sub Abbonamento' if numero_abbonamento else 'Semplice',
                    })
                else:
                    posti.append({
                        'sala': po.get('sala'), 'data': po.get('data'), 'ora': po.get('ora'), 'ora_fmt': ora_cerca,
                        'numero_posto': numero_posto, 'stato_posto': 'Libero',
                        'numero_prenotazione': None, 'codice_cliente': None,
                        'nome_cliente': '', 'cognome_cliente': '',
                        'numero_abbonamento': None, 'tipo_prenotazione': None,
                    })
            posti_disponibili = posti_totali - posti_occupati
    except Exception:
        errore = 'Non e stato possibile caricare la fascia oraria. Riprova piu tardi.'
    finally:
        client.close()

    return render(request, 'fasciaoraria.html', {'codiceSala': codice_sala, 'data': data_db, 'fascia': fascia, 'posti': posti, 'errore': errore, 'postiTotali': posti_totali, 'postiOccupati': posti_occupati, 'postiDisponibili': posti_disponibili})


# Dettaglio di un posto con la prenotazione collegata, se presente
def posto(request):
    codice_sala = (request.GET.get('sala') or '').strip()
    data_raw = (request.GET.get('data') or '').strip()
    ora_raw = (request.GET.get('ora') or '').strip()
    numero_posto = (request.GET.get('posto') or '').strip()
    data_db = fmt_data_db(data_raw)

    if not codice_sala or not codice_sala.isdigit() or not data_db or not ora_raw or not numero_posto or not numero_posto.isdigit():
        return redirect('/sale/')

    ora_cerca = ora_raw[:5]
    posto_doc = None
    errore = ''

    client, db = get_db()
    try:
        sala = db['Sala'].find_one({'codice': {'$in': [codice_sala, parse_int(codice_sala, -1)]}}, {'_id': 0})
        posto_raw = None
        for p in db['Posto'].find({}, {'_id': 0}):
            if str(p.get('sala')) == codice_sala and str(p.get('data')) == data_db and str(p.get('ora'))[:5] == ora_cerca and str(p.get('nProg')) == numero_posto:
                posto_raw = p
                break

        if not posto_raw or not sala:
            errore = 'Il posto richiesto non e stato trovato.'
        else:
            fascia = None
            for f in db['FasciaOraria'].find({}, {'_id': 0}):
                if str(f.get('sala')) == codice_sala and str(f.get('data')) == data_db and str(f.get('ora'))[:5] == ora_cerca:
                    fascia = f
                    break

            pren = None
            for pr in db['Prenotazione'].find({}, {'_id': 0}):
                if str(pr.get('sala')) == codice_sala and str(pr.get('data')) == data_db and str(pr.get('ora'))[:5] == ora_cerca and str(pr.get('posto')) == numero_posto:
                    pren = pr
                    break

            posto_doc = {
                'sala': posto_raw.get('sala'), 'data': posto_raw.get('data'), 'ora': posto_raw.get('ora'),
                'numero_posto': posto_raw.get('nProg'),
                'codice_sala': sala.get('codice'), 'nome_sala': sala.get('nome'), 'tema_sala': sala.get('tema'),
                'durata_fascia': fascia.get('durata') if fascia else '',
                'data_fmt': fmt_data_it(posto_raw.get('data')), 'ora_fmt': ora_cerca,
                'stato_posto': 'Libero', 'numero_prenotazione': None,
            }

            if pren:
                cli = db['Cliente'].find_one({'codice': {'$in': [pren.get('cliente'), parse_int(pren.get('cliente'), -1)]}}, {'_id': 0}) or {}
                sub_map = build_sub_map(db)
                numero_abbonamento = sub_map.get(str(pren.get('nProg')))
                posto_doc.update({
                    'stato_posto': 'Occupato',
                    'numero_prenotazione': pren.get('nProg'),
                    'data_prenotazione_fmt': fmt_data_it(pren.get('data')),
                    'ora_prenotazione_fmt': str(pren.get('ora', ''))[:5],
                    'codice_cliente': pren.get('cliente'),
                    'nome_cliente': cli.get('nome', ''),
                    'cognome_cliente': cli.get('cognome', ''),
                    'email_cliente': cli.get('email', ''),
                    'telefono_cliente': cli.get('tel', ''),
                    'numero_abbonamento': numero_abbonamento,
                    'tipo_prenotazione': 'Sub Abbonamento' if numero_abbonamento else 'Semplice',
                })
    except Exception:
        errore = 'Non e stato possibile caricare il posto. Riprova piu tardi.'
    finally:
        client.close()

    return render(request, 'posto.html', {'codiceSala': codice_sala, 'data': data_db, 'ora_fmt': ora_cerca, 'posto': posto_doc, 'errore': errore})


# Lista degli abbonamenti con filtri e paginazione
def abbonamenti_lista(request):
    record_per_pagina = 20
    pagina = max(1, parse_int(request.GET.get('pagina'), 1) or 1)
    n_abb = (request.GET.get('nAbb') or '').strip()
    nome = (request.GET.get('nome') or '').strip()
    cognome = (request.GET.get('cognome') or '').strip()
    stato_filtro = (request.GET.get('stato') or '').strip()

    abbonamenti = []
    errore = ''
    totale_abbonamenti = 0
    totale_pagine = 1
    pages = [1]

    client, db = get_db()
    try:
        oggi = date.today()
        clienti_map = {str(c.get('codice')): c for c in db['Cliente'].find({}, {'_id': 0})}
        sub_map = build_sub_map(db)
        conteggio_prenotazioni = {}
        for numero_ab in sub_map.values():
            conteggio_prenotazioni[str(numero_ab)] = conteggio_prenotazioni.get(str(numero_ab), 0) + 1

        all_abb = list(db['Abbonamento'].find({}, {'_id': 0}))
        risultati = []
        for a in all_abb:
            cli = clienti_map.get(str(a.get('cliente')), {})
            if n_abb and str(a.get('nAbb')) != n_abb:
                continue
            if nome and nome.lower() not in str(cli.get('nome', '')).lower():
                continue
            if cognome and cognome.lower() not in str(cli.get('cognome', '')).lower():
                continue
            stato = stato_abbonamento(a.get('inizio'), a.get('fine'), oggi)
            if stato_filtro and stato != stato_filtro:
                continue
            risultati.append({
                **a, 'nome': cli.get('nome', ''), 'cognome': cli.get('cognome', ''),
                'stato': stato, 'prezzo_fmt': fmt_prezzo(a.get('prezzo')),
                'numero_prenotazioni': conteggio_prenotazioni.get(str(a.get('nAbb')), 0),
            })

        risultati.sort(key=lambda a: parse_date_multi(a.get('fine')) or date.min, reverse=True)
        totale_abbonamenti = len(risultati)
        pagina, totale_pagine, pages = calcola_pagine(totale_abbonamenti, record_per_pagina, pagina)
        offset = (pagina - 1) * record_per_pagina
        abbonamenti = risultati[offset:offset + record_per_pagina]
    except Exception:
        errore = 'Non e stato possibile recuperare gli abbonamenti. Riprova piu tardi.'
    finally:
        client.close()

    return render(request, 'abbonamenti.html', {'abbonamenti': abbonamenti, 'totaleAbbonamenti': totale_abbonamenti, 'totalePagine': totale_pagine, 'pagina': pagina, 'pages': pages, 'nAbb': n_abb, 'nome': nome, 'cognome': cognome, 'stato': stato_filtro, 'errore': errore})


# Dettaglio di un abbonamento con le prenotazioni collegate
def abbonamento_dettaglio(request):
    n_abb = (request.GET.get('nAbb') or '').strip()
    if not n_abb or not n_abb.isdigit():
        return redirect('/abbonamenti/')

    abbonamento = None
    prenotazioni = []
    errore = ''
    numero_prenotazioni = 0

    client, db = get_db()
    try:
        abb = db['Abbonamento'].find_one({'nAbb': {'$in': [n_abb, parse_int(n_abb, -1)]}}, {'_id': 0})
        if not abb:
            client.close()
            return redirect('/abbonamenti/')

        cli = db['Cliente'].find_one({'codice': {'$in': [abb.get('cliente'), parse_int(abb.get('cliente'), -1)]}}, {'_id': 0}) or {}
        oggi = date.today()
        abbonamento = {
            **abb, 'nome': cli.get('nome', ''), 'cognome': cli.get('cognome', ''),
            'cf': cli.get('cf', ''), 'email': cli.get('email', ''), 'tel': cli.get('tel', ''),
            'stato': stato_abbonamento(abb.get('inizio'), abb.get('fine'), oggi),
            'prezzo_fmt': fmt_prezzo(abb.get('prezzo')),
        }

        sale_map = {str(s.get('codice')): s for s in db['Sala'].find({}, {'_id': 0})}
        prenotazioni_di_questo_abb = [str(k) for k, v in build_sub_map(db).items() if str(v) == n_abb]

        prs = [p for p in db['Prenotazione'].find({}, {'_id': 0}) if str(p.get('nProg')) in prenotazioni_di_questo_abb]
        prs.sort(key=lambda p: (parse_date_multi(p.get('data')) or date.min, p.get('ora', '')), reverse=True)
        for p in prs:
            sala = sale_map.get(str(p.get('sala')), {})
            p['nome_sala'] = sala.get('nome', '')
            p['data_fmt'] = fmt_data_it(p.get('data'))
            p['ora_fmt'] = str(p.get('ora', ''))[:5]
        prenotazioni = prs
        numero_prenotazioni = len(prenotazioni)
    except Exception:
        errore = "Non e stato possibile caricare l'abbonamento. Riprova piu tardi."
    finally:
        client.close()

    return render(request, 'abbonamento_dettaglio.html', {'abbonamento': abbonamento, 'prenotazioni': prenotazioni, 'numeroPrenotazioni': numero_prenotazioni, 'errore': errore})


# Lista delle prenotazioni con filtri multipli e paginazione
def prenotazioni_lista(request):
    data_da = (request.GET.get('data_da') or '').strip()
    data_a = (request.GET.get('data_a') or '').strip()
    sala = (request.GET.get('sala') or '').strip()
    cliente = (request.GET.get('cliente') or '').strip()
    abbonamento = (request.GET.get('abbonamento') or '').strip()
    tipo = (request.GET.get('tipo') or '').strip()
    numero = (request.GET.get('numero') or '').strip()

    record_per_pagina = 25
    pagina = max(1, parse_int(request.GET.get('pagina'), 1) or 1)

    prenotazioni = []
    errore = ''
    numero_prenotazioni = 0
    numero_pagine = 1
    pages = [1]
    sale_lista_menu = []

    client, db = get_db()
    try:
        sale_lista_menu = sorted(list(db['Sala'].find({}, {'codice': 1, 'nome': 1, '_id': 0})), key=lambda s: str(s.get('nome', '')).lower())

        data_da_obj = parse_date_multi(data_da) if data_da else None
        data_a_obj = parse_date_multi(data_a) if data_a else None

        if (data_da and not data_da_obj) or (data_a and not data_a_obj):
            errore = 'Formato data non valido. Usa il selettore per scegliere le date.'
        elif data_da_obj and data_a_obj and data_da_obj > data_a_obj:
            errore = 'La data di inizio non puo essere successiva alla data di fine.'
        else:
            clienti_map = {str(c.get('codice')): c for c in db['Cliente'].find({}, {'_id': 0})}
            sale_map = {str(s.get('codice')): s for s in db['Sala'].find({}, {'_id': 0})}
            sub_map = build_sub_map(db)

            raw = list(db['Prenotazione'].find({}, {'_id': 0}))
            filtered = []
            for p in raw:
                d = parse_date_multi(p.get('data'))
                if data_da_obj and (not d or d < data_da_obj):
                    continue
                if data_a_obj and (not d or d > data_a_obj):
                    continue
                if sala and str(p.get('sala')) != sala:
                    continue
                if cliente and str(p.get('cliente')) != cliente:
                    continue
                if numero and str(p.get('nProg')) != numero:
                    continue

                numero_abbonamento = sub_map.get(str(p.get('nProg')))

                if abbonamento and str(numero_abbonamento) != abbonamento:
                    continue
                if tipo == 'semplice' and numero_abbonamento:
                    continue
                if tipo == 'sub' and not numero_abbonamento:
                    continue

                cli = clienti_map.get(str(p.get('cliente')), {})
                sa = sale_map.get(str(p.get('sala')), {})
                filtered.append({
                    **p, 'cliente_nome': cli.get('nome', ''), 'cliente_cognome': cli.get('cognome', ''),
                    'sala_nome': sa.get('nome', ''), 'sala_codice': p.get('sala'),
                    'numero_abbonamento': numero_abbonamento,
                    'tipo_prenotazione': 'Sub Abbonamento' if numero_abbonamento else 'Semplice',
                    'data_fmt': fmt_data_it(p.get('data')), 'ora_fmt': str(p.get('ora', ''))[:5],
                })

            filtered.sort(key=lambda x: ((parse_date_multi(x.get('data')) or date.min), x.get('ora', ''), parse_int(x.get('nProg'), 0) or 0), reverse=True)
            numero_prenotazioni = len(filtered)
            pagina, numero_pagine, pages = calcola_pagine(numero_prenotazioni, record_per_pagina, pagina)
            offset = (pagina - 1) * record_per_pagina
            prenotazioni = filtered[offset:offset + record_per_pagina]
    finally:
        client.close()

    return render(request, 'prenotazioni.html', {'saleLista': sale_lista_menu, 'prenotazioni': prenotazioni, 'errore': errore, 'numeroPrenotazioni': numero_prenotazioni, 'numeroPagine': numero_pagine, 'pagina': pagina, 'pages': pages, 'data_da': data_da, 'data_a': data_a, 'sala': sala, 'cliente': cliente, 'abbonamento': abbonamento, 'tipo': tipo, 'numero': numero})