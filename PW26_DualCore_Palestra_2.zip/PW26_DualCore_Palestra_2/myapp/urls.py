from django.contrib import admin
from django.urls import path
from . import views

# Elenco di tutti gli URL (rotte) del sito e delle relative funzioni view
urlpatterns = [
    # Pannello di amministrazione di Django
    path('admin/', admin.site.urls),

    # Pagina Home
    path('', views.home, name='home'),

    # Gestione clienti (lista, dettaglio, creazione/modifica, eliminazione)
    path('clienti/', views.clienti_lista, name='clienti_lista'),
    path('clienti/dettaglio/', views.cliente_dettaglio, name='cliente_dettaglio'),
    path('clienti/form/', views.cliente_form, name='cliente_form'),
    path('clienti/elimina/', views.cliente_elimina, name='cliente_elimina'),

    # Gestione sale (lista e dettaglio)
    path('sale/', views.sale_lista, name='sale_lista'),
    path('sale/dettaglio/', views.sala_dettaglio, name='sala_dettaglio'),

    # Gestione fasce orarie e posti (dettaglio)
    path('fasce/dettaglio/', views.fasciaoraria, name='fasciaoraria'),
    path('posti/dettaglio/', views.posto, name='posto'),

    # Gestione abbonamenti (lista e dettaglio)
    path('abbonamenti/', views.abbonamenti_lista, name='abbonamenti_lista'),
    path('abbonamenti/dettaglio/', views.abbonamento_dettaglio, name='abbonamento_dettaglio'),

    # Gestione prenotazioni (lista con filtri)
    path('prenotazioni/', views.prenotazioni_lista, name='prenotazioni_lista'),
]