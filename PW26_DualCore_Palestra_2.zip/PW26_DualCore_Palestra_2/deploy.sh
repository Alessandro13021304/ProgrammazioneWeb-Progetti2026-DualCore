#!/bin/bash
set -e

# Porta di MongoDB: usa il primo parametro passato, altrimenti 27017 di default
# Esempio: ./deploy.sh 27018
MONGO_PORT="${1:-27017}"
export MONGO_HOST="localhost"
export MONGO_PORT
export MONGO_DB_NAME="PW26_Database"

echo "==============================================="
echo " Deploy DualCore Palestra - Progetto 2"
echo " Porta MongoDB usata: $MONGO_PORT"
echo "==============================================="

# Controlla che Python sia disponibile da riga di comando
if ! command -v python3 &> /dev/null; then
    echo "[ERRORE] Python non e stato trovato nel PATH."
    echo "Installare Python 3.12 e riprovare."
    exit 1
fi

# Crea l'ambiente virtuale solo se non esiste gia
if [ ! -d "venv" ]; then
    echo "Creazione ambiente virtuale..."
    python3 -m venv venv
else
    echo "Ambiente virtuale gia presente, salto la creazione."
fi

# Attiva l'ambiente virtuale
source venv/bin/activate

# Installa le librerie richieste
echo "Installazione librerie da requirements.txt..."
pip install -r requirements.txt --quiet

# Popola il database MongoDB con i dati dei CSV
echo "Popolamento del database in corso..."
python populate_db.py

# Avvia il server Django in background
echo "Avvio del server Django sulla porta 8000..."
python manage.py runserver 8000 &

# Attende qualche secondo prima di aprire il browser
sleep 3

# Apre il browser predefinito (funziona su macOS e sulla maggior parte delle distribuzioni Linux)
if command -v open &> /dev/null; then
    open http://127.0.0.1:8000/
elif command -v xdg-open &> /dev/null; then
    xdg-open http://127.0.0.1:8000/
fi

echo "==============================================="
echo " Deploy completato. Il sito e disponibile su:"
echo " http://127.0.0.1:8000/"
echo "==============================================="