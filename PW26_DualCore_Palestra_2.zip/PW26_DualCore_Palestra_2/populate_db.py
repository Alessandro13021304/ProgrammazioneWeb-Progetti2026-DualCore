import csv
import os
import pymongo

# Configurazione parametri MongoDB, letti dall'ambiente se presenti
# Cosi lo script di deploy puo scegliere la porta giusta senza modificare questo file
MONGO_HOST = os.environ.get("MONGO_HOST", "localhost")
MONGO_PORT = int(os.environ.get("MONGO_PORT", "27017"))
MONGO_DB_NAME = os.environ.get("MONGO_DB_NAME", "PW26_Database")

# Elenco dei file CSV del progetto
CSV_FILES = [
    "Cliente.csv",
    "Abbonamento.csv",
    "FasciaOraria.csv",
    "Posto.csv",
    "Prenotazione.csv",
    "SubAbbonamento.csv",
    "Sala.csv",
]

# Cartella in cui si trovano i file (impostare a "" se sono nella stessa cartella dello script)
DATA_DIR = "data"


# Funzione principale per popolare il database MongoDB con i dati dai file CSV
def populate():
    print(f"Connessione a MongoDB su {MONGO_HOST}:{MONGO_PORT}...")
    client = pymongo.MongoClient(f"mongodb://{MONGO_HOST}:{MONGO_PORT}/")
    db = client[MONGO_DB_NAME]

    # Ciclo su tutti i file CSV definiti
    for filename in CSV_FILES:
        # Costruzione del percorso del file
        file_path = os.path.join(DATA_DIR, filename) if DATA_DIR else filename

        if not os.path.exists(file_path):
            print(f"[ATTENZIONE] File non trovato: {file_path}")
            continue

        # Il nome della collezione corrisponde al nome del file senza estensione
        collection_name = os.path.splitext(filename)[0]
        coll = db[collection_name]

        # Svuotamento preventivo della collezione
        coll.drop()

        # Lettura con encoding utf-8-sig per rimuovere automaticamente eventuali caratteri BOM iniziali
        with open(file_path, mode="r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f, delimiter=";")
            records = [row for row in reader]

            if records:
                coll.insert_many(records)
                print(
                    f"Collezione '{collection_name}': inseriti {len(records)} documenti."
                )
            else:
                print(f"Collezione '{collection_name}': nessun record presente nel file.")

    client.close()
    print("Popolamento del database completato con successo.")


# Esecuzione dello script solo se lanciato direttamente (non se importato come modulo)
if __name__ == "__main__":
    populate()