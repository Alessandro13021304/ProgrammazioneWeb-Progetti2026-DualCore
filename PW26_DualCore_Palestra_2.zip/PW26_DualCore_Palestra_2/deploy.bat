@echo off
setlocal enabledelayedexpansion

REM Porta di MongoDB: usa il primo parametro passato, altrimenti 27017 di default
REM Esempio: deploy.bat 27018
set MONGO_PORT=%1
if "%MONGO_PORT%"=="" set MONGO_PORT=27017

set MONGO_HOST=localhost
set MONGO_DB_NAME=PW26_Database

echo ===============================================
echo  Deploy DualCore Palestra - Progetto 2
echo  Porta MongoDB usata: %MONGO_PORT%
echo ===============================================

REM Controlla che Python sia disponibile da riga di comando
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERRORE] Python non e stato trovato nel PATH.
    echo Installare Python 3.12 e riprovare.
    exit /b 1
)

REM Crea l'ambiente virtuale solo se non esiste gia
if not exist "venv\" (
    echo Creazione ambiente virtuale...
    python -m venv venv
) else (
    echo Ambiente virtuale gia presente, salto la creazione.
)

REM Attiva l'ambiente virtuale
call venv\Scripts\activate.bat

REM Installa le librerie richieste
echo Installazione librerie da requirements.txt...
pip install -r requirements.txt --quiet

if errorlevel 1 (
    echo [ERRORE] Installazione librerie fallita.
    exit /b 1
)

REM Popola il database MongoDB con i dati dei CSV
echo Popolamento del database in corso...
python populate_db.py

if errorlevel 1 (
    echo [ERRORE] Popolamento del database fallito.
    echo Verificare che MongoDB sia attivo sulla porta %MONGO_PORT%.
    exit /b 1
)

REM Avvia il server Django in background e apre il browser
echo Avvio del server Django sulla porta 8000...
start "Server Django" cmd /k "call venv\Scripts\activate.bat && python manage.py runserver 8000"

REM Attende qualche secondo prima di aprire il browser
timeout /t 3 /nobreak >nul
start http://127.0.0.1:8000/

echo ===============================================
echo  Deploy completato. Il sito e disponibile su:
echo  http://127.0.0.1:8000/
echo ===============================================

endlocal