<?php

// Nome del file della pagina corrente
$paginaCorrente = basename($_SERVER['PHP_SELF']);

// Aggiunge la classe active al link della pagina corrente
function voceAttiva(string $pagina, string $corrente): string
{
    return $pagina === $corrente ? ' class="active"' : '';
}

?>

<!-- Menu principale del sito -->
<nav>
    <ul>
        <li>
            <a href="<?= $basePath ?>pages/clienti.php"<?= voceAttiva('clienti.php', $paginaCorrente) ?>>
                Clienti
            </a>
        </li>
        <li>
            <a href="<?= $basePath ?>pages/sale.php"<?= voceAttiva('sale.php', $paginaCorrente) ?>>
                Sale
            </a>
        </li>
        <li>
            <a href="<?= $basePath ?>pages/abbonamenti.php"<?= voceAttiva('abbonamenti.php', $paginaCorrente) ?>>
                Abbonamenti
            </a>
        </li>
    </ul>
</nav>