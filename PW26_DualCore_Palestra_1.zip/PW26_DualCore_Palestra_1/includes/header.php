<?php

// Imposta il percorso base se non gia' stato definito dalla pagina chiamante
$basePath = $basePath ?? '';

// Crea il percorso del file CSS sul server
$cssFile = __DIR__ . '/../assets/css/style.css';

// Aggiunge la data di modifica del CSS per aggiornare la cache del browser
$cssVersion = file_exists($cssFile) ? filemtime($cssFile) : time();

?>
<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- Titolo della pagina, modificabile dalle singole pagine -->
    <title><?= htmlspecialchars($titoloPagina ?? 'DualCore Palestra') ?></title>

    <!-- Font del titolo caricato da Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600;700&display=swap" rel="stylesheet">

    <!-- Collega il foglio di stile principale -->
    <link rel="stylesheet" href="<?= $basePath ?>assets/css/style.css?v=<?= $cssVersion ?>">
</head>
<body>

    <!-- Intestazione comune a tutte le pagine -->
    <header>
        <div class="header-inner">
            <div class="logo">
                <span>DualCore Palestra</span>
            </div>
            <p class="header-subtitle">Gestione clienti, sale e prenotazioni</p>
        </div>
    </header>