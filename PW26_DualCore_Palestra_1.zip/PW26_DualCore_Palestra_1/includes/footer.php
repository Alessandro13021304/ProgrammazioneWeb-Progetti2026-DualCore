<!-- Footer comune del sito -->
<footer>
  <p>
    Progetto d'esame – Programmazione Web 2026 &nbsp;|&nbsp;
    I dati sono fittizi e generati a scopo didattico.
  </p>
</footer>
