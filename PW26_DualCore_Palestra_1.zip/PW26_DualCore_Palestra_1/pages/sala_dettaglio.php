<?php

// Connessione al database
require_once __DIR__ . '/../config/database.php';

// Percorso base e titolo pagina
$basePath = '../';
$titoloPagina = 'DualCore Palestra - Dettaglio sala';

// Formatta una data dal formato database al formato italiano
function formattaDataIt(?string $data): string
{
    if ($data === null || trim($data) === '') {
        return '';
    }

    $data = trim($data);
    $dateTime = DateTime::createFromFormat('!Y-m-d', $data);

    if ($dateTime !== false && $dateTime->format('Y-m-d') === $data) {
        return $dateTime->format('d/m/Y');
    }

    return htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
}

// Mostra l'orario come HH:MM
function formattaOra(?string $ora): string
{
    if ($ora === null || trim($ora) === '') {
        return '';
    }

    return htmlspecialchars(substr(trim($ora), 0, 5), ENT_QUOTES, 'UTF-8');
}

// Codice sala ricevuto dall'URL
$codiceSala = trim($_GET['codice'] ?? '');

if ($codiceSala === '' || !ctype_digit($codiceSala)) {
    header('Location: sale.php');
    exit;
}

// Impostazioni paginazione
$righePerPagina = 20;
$pagina = max(1, (int) ($_GET['pagina'] ?? 1));
$offset = 0;

// Variabili della pagina
$sala = null;
$fasce = [];
$errore = '';

$numeroFasce = 0;
$numeroPosti = 0;
$numeroPrenotazioni = 0;

$numeroPagine = 1;

try {
    // Recupera la sala selezionata
    $stmtSala = $pdo->prepare(
        'SELECT codice, nome, tema, mq
         FROM Sala
         WHERE codice = :codice'
    );
    $stmtSala->execute([':codice' => (int) $codiceSala]);
    $sala = $stmtSala->fetch(PDO::FETCH_ASSOC);

    if (!$sala) {
        header('Location: sale.php');
        exit;
    }

    // Conta le fasce orarie della sala
    $stmtContaFasce = $pdo->prepare('SELECT COUNT(*) FROM FasciaOraria WHERE sala = :sala');
    $stmtContaFasce->execute([':sala' => (int) $codiceSala]);
    $numeroFasce = (int) $stmtContaFasce->fetchColumn();

    // Conta i posti totali della sala
    $stmtContaPosti = $pdo->prepare('SELECT COUNT(*) FROM Posto WHERE sala = :sala');
    $stmtContaPosti->execute([':sala' => (int) $codiceSala]);
    $numeroPosti = (int) $stmtContaPosti->fetchColumn();

    // Conta le prenotazioni della sala
    $stmtContaPrenotazioni = $pdo->prepare('SELECT COUNT(*) FROM Prenotazione WHERE sala = :sala');
    $stmtContaPrenotazioni->execute([':sala' => (int) $codiceSala]);
    $numeroPrenotazioni = (int) $stmtContaPrenotazioni->fetchColumn();

    // Calcola il numero di pagine delle fasce orarie
    $numeroPagine = max(1, (int) ceil($numeroFasce / $righePerPagina));

    if ($pagina > $numeroPagine) {
        $pagina = $numeroPagine;
    }

    $offset = ($pagina - 1) * $righePerPagina;

    // Recupera le fasce della sala con i conteggi dei posti
    $stmtFasce = $pdo->prepare(
        'SELECT
            fo.sala,
            fo.data,
            fo.ora,
            fo.durata,
            COUNT(DISTINCT p.nProg) AS posti_totali,
            COUNT(DISTINCT pr.nProg) AS posti_prenotati
         FROM FasciaOraria fo
         LEFT JOIN Posto p
             ON p.sala = fo.sala
            AND p.data = fo.data
            AND p.ora = fo.ora
         LEFT JOIN Prenotazione pr
             ON pr.sala = p.sala
            AND pr.data = p.data
            AND pr.ora = p.ora
            AND pr.posto = p.nProg
         WHERE fo.sala = :sala
         GROUP BY fo.sala, fo.data, fo.ora, fo.durata
         ORDER BY fo.data DESC, fo.ora DESC
         LIMIT :limite OFFSET :offset'
    );

    $stmtFasce->bindValue(':sala', (int) $codiceSala, PDO::PARAM_INT);
    $stmtFasce->bindValue(':limite', $righePerPagina, PDO::PARAM_INT);
    $stmtFasce->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmtFasce->execute();

    $fasce = $stmtFasce->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $errore = 'Non e stato possibile caricare i dati della sala. Riprova piu tardi.';
}

// Crea il link a una pagina della paginazione
function creaLinkPagina(int $pagina, string $codiceSala): string
{
    return 'sala_dettaglio.php?' . http_build_query([
        'codice' => $codiceSala,
        'pagina' => $pagina
    ]);
}

require_once __DIR__ . '/../includes/header.php';

?>

<main class="corpo">

    <!-- Colonna sinistra: ritorno e collegamenti -->
    <aside class="area-laterale">

        <section class="pannello-laterale">

            <a class="breadcrumb" href="sale.php">
                &larr; Torna alla ricerca sale
            </a>

        </section>

        <?php if ($sala): ?>

            <section class="pannello-laterale">

                <h3>Collegamenti</h3>

                <a
                    class="link-azione"
                    href="prenotazioni.php?sala=<?= urlencode($sala['codice']) ?>"
                >
                    Vedi prenotazioni sala
                </a>

            </section>

        <?php endif; ?>

    </aside>

    <!-- Colonna centrale: dettagli e fasce orarie della sala -->
    <section class="area-contenuto">

        <?php if ($errore !== ''): ?>

            <p class="msg-errore">
                <?= htmlspecialchars($errore, ENT_QUOTES, 'UTF-8') ?>
            </p>

        <?php elseif ($sala): ?>

            <h2>
                <?= htmlspecialchars($sala['nome'], ENT_QUOTES, 'UTF-8') ?>
            </h2>

            <!-- Dati principali della sala -->
            <section class="scheda">

                <div class="scheda-campo">
                    <label>Nome</label>
                    <span><?= htmlspecialchars($sala['nome'], ENT_QUOTES, 'UTF-8') ?></span>
                </div>

                <div class="scheda-campo">
                    <label>Tema</label>
                    <span><?= htmlspecialchars($sala['tema'], ENT_QUOTES, 'UTF-8') ?></span>
                </div>

                <div class="scheda-campo">
                    <label>Superficie</label>
                    <span><?= htmlspecialchars((string) $sala['mq'], ENT_QUOTES, 'UTF-8') ?> m²</span>
                </div>

            </section>

            <h2 class="sezione-anchor">
                Fasce orarie
                <small style="font-size: 0.75rem; font-weight: 400; color: var(--muted); margin-left: 0.5rem;">
                    <?= $numeroFasce ?>
                </small>
            </h2>

            <?php if (empty($fasce)): ?>

                <p class="msg-avviso">
                    Non risultano fasce orarie pianificate per questa sala.
                </p>

            <?php else: ?>

                <section class="contenuto-risultati">

                    <table>
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Ora</th>
                                <th>Durata</th>
                                <th>Posti</th>
                                <th>Occupati</th>
                                <th>Disponibili</th>
                                <th>Occupazione</th>
                                <th>Azioni</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php foreach ($fasce as $fascia): ?>

                                <?php
                                $postiTotaliFascia = (int) $fascia['posti_totali'];
                                $postiPrenotatiFascia = (int) $fascia['posti_prenotati'];
                                $postiDisponibiliFascia = max(0, $postiTotaliFascia - $postiPrenotatiFascia);

                                $percentualeOccupazione = 0;

                                if ($postiTotaliFascia > 0) {
                                    $percentualeOccupazione = (int) round(
                                        ($postiPrenotatiFascia / $postiTotaliFascia) * 100
                                    );
                                }

                                $urlFascia = 'fasciaoraria.php?' . http_build_query([
                                    'sala' => $fascia['sala'],
                                    'data' => $fascia['data'],
                                    'ora' => substr($fascia['ora'], 0, 5)
                                ]);

                                $urlPrenotazioniFascia = 'prenotazioni.php?' . http_build_query([
                                    'sala' => $fascia['sala'],
                                    'data_da' => $fascia['data'],
                                    'data_a' => $fascia['data']
                                ]);
                                ?>

                                <tr>
                                    <td data-label="Data">
                                        <?= formattaDataIt($fascia['data']) ?>
                                    </td>

                                    <td data-label="Ora">
                                        <?= formattaOra($fascia['ora']) ?>
                                    </td>

                                    <td data-label="Durata">
                                        <?= htmlspecialchars((string) $fascia['durata'], ENT_QUOTES, 'UTF-8') ?> min
                                    </td>

                                    <td data-label="Posti">
                                        <?= $postiTotaliFascia ?>
                                    </td>

                                    <td data-label="Occupati">
                                        <?= $postiPrenotatiFascia ?>
                                    </td>

                                    <td data-label="Disponibili">
                                        <?= $postiDisponibiliFascia ?>
                                    </td>

                                    <td data-label="Occupazione" class="occupazione-cella">
                                        <?= $percentualeOccupazione ?>%
                                        <div class="posti-bar" aria-hidden="true">
                                            <div
                                                class="posti-bar-fill"
                                                style="width: <?= $percentualeOccupazione ?>%;"
                                            ></div>
                                        </div>
                                    </td>

                                    <td data-label="Azioni">
                                        <div class="azioni-tabella">

                                            <a
                                                class="btn-secondario"
                                                href="<?= htmlspecialchars($urlFascia, ENT_QUOTES, 'UTF-8') ?>"
                                            >
                                                Vedi fascia
                                            </a>

                                            <?php if ($postiPrenotatiFascia > 0): ?>
                                                <a
                                                    class="btn-secondario"
                                                    href="<?= htmlspecialchars($urlPrenotazioniFascia, ENT_QUOTES, 'UTF-8') ?>"
                                                >
                                                    Prenotazioni
                                                </a>
                                            <?php endif; ?>

                                        </div>
                                    </td>
                                </tr>

                            <?php endforeach; ?>
                        </tbody>
                    </table>

                </section>

                <?php if ($numeroPagine > 1): ?>

                    <nav class="pagination-wrap" aria-label="Paginazione fasce orarie">

                        <div class="pagination-info">
                            Pagina <?= $pagina ?> di <?= $numeroPagine ?>
                        </div>

                        <div class="pagination-nav">

                            <?php if ($pagina > 1): ?>
                                <a
                                    class="pagination-link pagination-arrow"
                                    href="<?= htmlspecialchars(creaLinkPagina($pagina - 1, $codiceSala), ENT_QUOTES, 'UTF-8') ?>"
                                >
                                    &larr; Precedente
                                </a>
                            <?php else: ?>
                                <span class="pagination-disabled pagination-arrow">&larr; Precedente</span>
                            <?php endif; ?>

                            <?php
                            $inizio = max(1, $pagina - 2);
                            $fine = min($numeroPagine, $pagina + 2);
                            ?>

                            <?php for ($i = $inizio; $i <= $fine; $i++): ?>

                                <?php if ($i === $pagina): ?>
                                    <span class="pagination-current"><?= $i ?></span>
                                <?php else: ?>
                                    <a
                                        class="pagination-link"
                                        href="<?= htmlspecialchars(creaLinkPagina($i, $codiceSala), ENT_QUOTES, 'UTF-8') ?>"
                                    >
                                        <?= $i ?>
                                    </a>
                                <?php endif; ?>

                            <?php endfor; ?>

                            <?php if ($pagina < $numeroPagine): ?>
                                <a
                                    class="pagination-link pagination-arrow"
                                    href="<?= htmlspecialchars(creaLinkPagina($pagina + 1, $codiceSala), ENT_QUOTES, 'UTF-8') ?>"
                                >
                                    Successiva &rarr;
                                </a>
                            <?php else: ?>
                                <span class="pagination-disabled pagination-arrow">Successiva &rarr;</span>
                            <?php endif; ?>

                        </div>

                    </nav>

                <?php endif; ?>

            <?php endif; ?>

        <?php endif; ?>

    </section>

    <!-- Menu laterale destro -->
    <?php require_once __DIR__ . '/../includes/nav.php'; ?>

</main>

<!-- Footer -->
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

</body>
</html>