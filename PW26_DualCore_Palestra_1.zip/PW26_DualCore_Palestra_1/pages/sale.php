<?php

// Connessione al database
require_once __DIR__ . '/../config/database.php';

// Percorso base e titolo pagina
$basePath = '../';
$titoloPagina = 'DualCore Palestra - Ricerca Sale';

// Filtri ricevuti dal form
$nome = trim($_GET['nome'] ?? '');
$tema = trim($_GET['tema'] ?? '');

// Carica i temi disponibili per il menu a tendina
$temiLista = [];

try {
    $stmtTemi = $pdo->query(
        "SELECT DISTINCT tema
         FROM Sala
         WHERE tema IS NOT NULL
         ORDER BY tema"
    );
    $temiLista = $stmtTemi->fetchAll(PDO::FETCH_COLUMN);
} catch (Exception $e) {
    $temiLista = [];
}

// Costruisce la query di ricerca delle sale
// Le sottoquery contano le fasce orarie e le prenotazioni di ogni sala
$sql = "SELECT
            s.codice,
            s.nome,
            s.tema,
            s.mq,
            (SELECT COUNT(*) FROM FasciaOraria f WHERE f.sala = s.codice) AS num_fasce,
            (SELECT COUNT(*) FROM Prenotazione p WHERE p.sala = s.codice) AS num_prenotazioni
        FROM Sala s
        WHERE 1=1";

$params = [];

// Filtro per nome della sala
if ($nome !== '') {
    $sql .= ' AND s.nome LIKE ?';
    $params[] = '%' . $nome . '%';
}

// Filtro per tema della sala
if ($tema !== '') {
    $sql .= ' AND s.tema = ?';
    $params[] = $tema;
}

$sql .= ' ORDER BY s.nome ASC';

// Variabili dei risultati
$sale = [];
$errore = '';

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $sale = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $errore = 'Errore durante la ricerca. Riprova piu tardi.';
}

// Include header e CSS
require_once __DIR__ . '/../includes/header.php';

?>

<main class="corpo">

    <!-- Colonna sinistra: filtri di ricerca -->
    <aside class="area-laterale">

        <section class="filtro-ricerca">
            <form method="get" action="sale.php">

                <label for="nome">
                    Nome sala
                    <input
                        type="text"
                        id="nome"
                        name="nome"
                        value="<?= htmlspecialchars($nome, ENT_QUOTES, 'UTF-8') ?>"
                    >
                </label>

                <label for="tema">
                    Tema
                    <select id="tema" name="tema">
                        <option value="">-- Tutti i temi --</option>
                        <?php foreach ($temiLista as $t): ?>
                            <option
                                value="<?= htmlspecialchars($t, ENT_QUOTES, 'UTF-8') ?>"
                                <?= $tema === $t ? 'selected' : '' ?>
                            >
                                <?= htmlspecialchars($t, ENT_QUOTES, 'UTF-8') ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <button type="submit" class="btn">Cerca</button>
                <a href="sale.php" class="btn-secondario">Azzera filtri</a>

            </form>
        </section>

    </aside>

    <!-- Contenuto centrale -->
    <section class="area-contenuto">

        <h2>Ricerca Sale</h2>

        <?php if ($errore !== ''): ?>

            <p class="msg-errore">
                <?= htmlspecialchars($errore, ENT_QUOTES, 'UTF-8') ?>
            </p>

        <?php elseif (empty($sale)): ?>

            <p class="msg-avviso">
                Nessuna sala trovata per i criteri inseriti.
            </p>

        <?php else: ?>

            <!-- Riepilogo dei risultati -->
            <section class="riepilogo-risultati">
                <p>
                    Visualizzate <?= count($sale) ?>
                    <?= count($sale) !== 1 ? 'sale' : 'sala' ?>.
                </p>
            </section>

            <!-- Tabella delle sale -->
            <section class="contenuto-risultati">

                <table class="tabella">
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Tema</th>
                            <th>Superficie</th>
                            <th>Fasce Orarie</th>
                            <th>Prenotazioni</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php foreach ($sale as $s): ?>

                            <tr>

                                <td data-label="Nome">
                                    <a href="sala_dettaglio.php?codice=<?= urlencode($s['codice']) ?>">
                                        <?= htmlspecialchars($s['nome'], ENT_QUOTES, 'UTF-8') ?>
                                    </a>
                                </td>

                                <td data-label="Tema">
                                    <?= htmlspecialchars($s['tema'] ?? '-', ENT_QUOTES, 'UTF-8') ?>
                                </td>

                                <td data-label="Superficie">
                                    <?= htmlspecialchars((string) $s['mq'], ENT_QUOTES, 'UTF-8') ?> m&sup2;
                                </td>

                                <td data-label="Fasce Orarie">

                                    <?php if ($s['num_fasce'] > 0): ?>
                                        <a href="sala_dettaglio.php?codice=<?= urlencode($s['codice']) ?>">
                                            <?= (int) $s['num_fasce'] ?>
                                        </a>
                                    <?php else: ?>
                                        <span class="nessuno">Nessuna</span>
                                    <?php endif; ?>

                                </td>

                                <td data-label="Prenotazioni">

                                    <?php if ($s['num_prenotazioni'] > 0): ?>
                                        <a href="prenotazioni.php?sala=<?= urlencode($s['codice']) ?>">
                                            <?= (int) $s['num_prenotazioni'] ?>
                                        </a>
                                    <?php else: ?>
                                        <span class="nessuno">0</span>
                                    <?php endif; ?>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    </tbody>
                </table>

            </section>

        <?php endif; ?>

    </section>

    <!-- Menu laterale destro -->
    <?php require_once __DIR__ . '/../includes/nav.php'; ?>

</main>

<!-- Footer -->
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

</body>
</html>