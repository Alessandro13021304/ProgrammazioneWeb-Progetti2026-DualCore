<?php

// Connessione al database
require_once __DIR__ . '/../config/database.php';

// Percorso base e titolo pagina
$basePath = '../';
$titoloPagina = 'DualCore Palestra - Dettaglio abbonamento';

// Formatta una data testuale GG/MM/AAAA
function formattaDataIt(?string $data): string
{
    if ($data === null || trim($data) === '') {
        return '';
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Mostra l'orario come HH:MM
function formattaOra(?string $ora): string
{
    if ($ora === null || trim($ora) === '') {
        return '';
    }
    return htmlspecialchars(substr(trim($ora), 0, 5), ENT_QUOTES, 'UTF-8');
}

// Numero abbonamento ricevuto dall'URL
$nAbb = trim($_GET['nAbb'] ?? '');

// Torna alla lista se manca il parametro
if ($nAbb === '' || !ctype_digit($nAbb)) {
    header('Location: abbonamenti.php');
    exit;
}

// Variabili della pagina
$abbonamento = null;
$prenotazioni = [];
$errore = '';
$numeroPrenotazioni = 0;

try {
    // Espressione per calcolare lo stato dell'abbonamento
    $espressioneStato = "CASE
        WHEN CURDATE() < STR_TO_DATE(a.inizio, '%d/%m/%Y') THEN 'Futuro'
        WHEN CURDATE() BETWEEN STR_TO_DATE(a.inizio, '%d/%m/%Y') AND STR_TO_DATE(a.fine, '%d/%m/%Y') THEN 'Attivo'
        ELSE 'Scaduto'
    END";

    // Recupera i dati dell'abbonamento e del cliente collegato
    $stmtAbb = $pdo->prepare(
        "SELECT a.nAbb, a.cliente, a.inizio, a.fine, a.prezzo,
                c.nome, c.cognome, c.cf, c.email, c.tel,
                $espressioneStato AS stato
         FROM Abbonamento a
         INNER JOIN Cliente c ON c.codice = a.cliente
         WHERE a.nAbb = ?"
    );
    $stmtAbb->execute([$nAbb]);
    $abbonamento = $stmtAbb->fetch(PDO::FETCH_ASSOC);

    // Torna alla lista se l'abbonamento non esiste
    if (!$abbonamento) {
        header('Location: abbonamenti.php');
        exit;
    }

    // Recupera le prenotazioni collegate tramite SubAbbonamento
    $stmtPre = $pdo->prepare(
        "SELECT p.nProg, p.sala, p.data, p.ora, p.posto,
                s.nome AS nome_sala, s.tema AS tema_sala
         FROM SubAbbonamento sa
         INNER JOIN Prenotazione p ON p.nProg = sa.prenotazione
         INNER JOIN Sala s ON s.codice = p.sala
         WHERE sa.abbonamento = ?
         ORDER BY p.data DESC, p.ora DESC"
    );
    $stmtPre->execute([$nAbb]);
    $prenotazioni = $stmtPre->fetchAll(PDO::FETCH_ASSOC);
    $numeroPrenotazioni = count($prenotazioni);

} catch (PDOException $e) {
    $errore = 'Non e stato possibile caricare l\'abbonamento. Riprova piu tardi.';
}

// Include header e CSS
require_once __DIR__ . '/../includes/header.php';

?>

<main class="corpo">

    <!-- Colonna sinistra: ritorno e collegamenti -->
    <aside class="area-laterale">

        <section class="pannello-laterale">
            <a class="breadcrumb" href="abbonamenti.php">
                &larr; Torna alla lista abbonamenti
            </a>
        </section>

        <?php if ($abbonamento): ?>
            <section class="pannello-laterale">
                <h3>Collegamenti</h3>
                <a class="link-azione" href="cliente_dettaglio.php?codice=<?= urlencode($abbonamento['cliente']) ?>">
                    Scheda cliente
                </a>
                <a class="link-azione" href="prenotazioni.php?abbonamento=<?= urlencode($abbonamento['nAbb']) ?>">
                    Tutte le prenotazioni
                </a>
            </section>
        <?php endif; ?>

    </aside>

    <!-- Contenuto centrale -->
    <section class="area-contenuto">

        <?php if ($errore !== ''): ?>

            <p class="msg-errore">
                <?= htmlspecialchars($errore, ENT_QUOTES, 'UTF-8') ?>
            </p>

        <?php elseif ($abbonamento): ?>

            <h2>
                Abbonamento #<?= htmlspecialchars((string) $abbonamento['nAbb'], ENT_QUOTES, 'UTF-8') ?>
            </h2>

            <!-- Dati dell'abbonamento -->
            <section class="scheda">

                <div class="scheda-campo">
                    <label>Numero</label>
                    <span>#<?= htmlspecialchars((string) $abbonamento['nAbb'], ENT_QUOTES, 'UTF-8') ?></span>
                </div>

                <div class="scheda-campo">
                    <label>Cliente</label>
                    <span>
                        <a class="link-cliente" href="cliente_dettaglio.php?codice=<?= urlencode($abbonamento['cliente']) ?>">
                            <?= htmlspecialchars($abbonamento['nome'] . ' ' . $abbonamento['cognome'], ENT_QUOTES, 'UTF-8') ?>
                        </a>
                    </span>
                </div>

                <div class="scheda-campo">
                    <label>Codice fiscale</label>
                    <span><?= htmlspecialchars($abbonamento['cf'], ENT_QUOTES, 'UTF-8') ?></span>
                </div>

                <div class="scheda-campo">
                    <label>Email</label>
                    <span>
                        <a href="mailto:<?= htmlspecialchars($abbonamento['email'], ENT_QUOTES, 'UTF-8') ?>">
                            <?= htmlspecialchars($abbonamento['email'], ENT_QUOTES, 'UTF-8') ?>
                        </a>
                    </span>
                </div>

                <div class="scheda-campo">
                    <label>Telefono</label>
                    <span>
                        <a href="tel:<?= htmlspecialchars($abbonamento['tel'], ENT_QUOTES, 'UTF-8') ?>">
                            <?= htmlspecialchars($abbonamento['tel'], ENT_QUOTES, 'UTF-8') ?>
                        </a>
                    </span>
                </div>

                <div class="scheda-campo">
                    <label>Data inizio</label>
                    <span><?= formattaDataIt($abbonamento['inizio']) ?></span>
                </div>

                <div class="scheda-campo">
                    <label>Data fine</label>
                    <span><?= formattaDataIt($abbonamento['fine']) ?></span>
                </div>

                <div class="scheda-campo">
                    <label>Prezzo</label>
                    <span><?= number_format((float) $abbonamento['prezzo'], 2, ',', '.') ?> &euro;</span>
                </div>

                <div class="scheda-campo">
                    <label>Stato</label>
                    <span>
                        <?php if ($abbonamento['stato'] === 'Attivo'): ?>
                            <span class="badge badge-attivo">Attivo</span>
                        <?php elseif ($abbonamento['stato'] === 'Futuro'): ?>
                            <span class="badge badge-futuro">Futuro</span>
                        <?php else: ?>
                            <span class="badge badge-scaduto">Scaduto</span>
                        <?php endif; ?>
                    </span>
                </div>

            </section>

            <h2 class="sezione-anchor">
                Prenotazioni con questo abbonamento
                <small style="font-size:.75rem;font-weight:400;color:var(--muted);margin-left:.5rem;">
                    <?= $numeroPrenotazioni ?>
                </small>
            </h2>

            <?php if (empty($prenotazioni)): ?>

                <p class="msg-avviso">
                    Nessuna prenotazione registrata con questo abbonamento.
                </p>

            <?php else: ?>

                <!-- Tabella delle prenotazioni -->
                <section class="contenuto-risultati">

                    <table class="tabella">
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Ora</th>
                                <th>Sala</th>
                                <th>Posto</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php foreach ($prenotazioni as $p): ?>

                                <?php
                                // Link alla fascia oraria della prenotazione
                                $urlFascia = 'fasciaoraria.php?' . http_build_query([
                                    'sala' => $p['sala'],
                                    'data' => $p['data'],
                                    'ora' => substr($p['ora'], 0, 5)
                                ]);

                                // Link al dettaglio del posto prenotato
                                $urlPosto = 'posto.php?' . http_build_query([
                                    'sala' => $p['sala'],
                                    'data' => $p['data'],
                                    'ora' => substr($p['ora'], 0, 5),
                                    'posto' => $p['posto']
                                ]);
                                ?>

                                <tr>
                                    <td data-label="Data">
                                        <?= formattaDataIt($p['data']) ?>
                                    </td>

                                    <td data-label="Ora">
                                        <a href="<?= htmlspecialchars($urlFascia, ENT_QUOTES, 'UTF-8') ?>">
                                            <?= formattaOra($p['ora']) ?>
                                        </a>
                                    </td>

                                    <td data-label="Sala">
                                        <a href="sala_dettaglio.php?codice=<?= urlencode($p['sala']) ?>">
                                            <?= htmlspecialchars($p['nome_sala'], ENT_QUOTES, 'UTF-8') ?>
                                        </a>
                                    </td>

                                    <td data-label="Posto">
                                        <a href="<?= htmlspecialchars($urlPosto, ENT_QUOTES, 'UTF-8') ?>">
                                            <?= htmlspecialchars((string) $p['posto'], ENT_QUOTES, 'UTF-8') ?>
                                        </a>
                                    </td>
                                </tr>

                            <?php endforeach; ?>

                        </tbody>
                    </table>

                </section>

            <?php endif; ?>

        <?php endif; ?>

    </section>

    <!-- Menu laterale destro -->
    <?php require_once __DIR__ . '/../includes/nav.php'; ?>

</main>

<!-- Footer -->
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

</body>
</html>