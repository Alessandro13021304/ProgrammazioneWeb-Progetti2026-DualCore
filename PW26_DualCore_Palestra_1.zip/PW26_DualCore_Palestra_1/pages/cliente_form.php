<?php

// Include la connessione al database
require_once __DIR__ . '/../config/database.php';

// Imposta il percorso base e il titolo della pagina
$basePath = '../';
$titoloPagina = 'DualCore Palestra - ' . (isset($_GET['codice']) ? 'Modifica Cliente' : 'Nuovo Cliente');

// Converte una data in formato compatibile con il campo input date
function preparaDataPerInput($data)
{
    if ($data === null || trim($data) === '') {
        return '';
    }

    $data = trim($data);

    $formati = [
        'Y-m-d',
        'd/m/Y',
        'd-m-Y',
        'Y/m/d'
    ];

    foreach ($formati as $formato) {
        $dataConvertita = DateTime::createFromFormat('!' . $formato, $data);

        if (
            $dataConvertita !== false &&
            $dataConvertita->format($formato) === $data
        ) {
            return $dataConvertita->format('Y-m-d');
        }
    }

    return '';
}

// Verifica che nome e cognome contengano solo lettere, spazi, apostrofi e trattini
function nomeCognomeValido($testo)
{
    $testo = trim($testo);

    if ($testo === '') {
        return false;
    }

    return preg_match(
        "/^[A-Za-zÀ-ÖØ-öø-ÿ]+(?:[ '\-][A-Za-zÀ-ÖØ-öø-ÿ]+)*$/u",
        $testo
    ) === 1;
}

// Accetta un cellulare italiano scritto in qualsiasi formato e lo riporta a +39 XXX XXX XXXX
function formattaTelefono($telefono)
{
    // Tiene solo le cifre, ignorando +, spazi, trattini e punti
    $soloNumeri = preg_replace('/\D+/', '', $telefono);

    // Toglie il prefisso internazionale scritto come 0039
    if (strlen($soloNumeri) === 14 && substr($soloNumeri, 0, 4) === '0039') {
        $soloNumeri = substr($soloNumeri, 4);
    }

    // Toglie il prefisso internazionale scritto come 39 (solo se il numero e' completo di prefisso)
    if (strlen($soloNumeri) === 12 && substr($soloNumeri, 0, 2) === '39') {
        $soloNumeri = substr($soloNumeri, 2);
    }

    // Un cellulare italiano valido ha 10 cifre e inizia per 3
    if (!preg_match('/^3\d{9}$/', $soloNumeri)) {
        return false;
    }

    return '+39 ' .
        substr($soloNumeri, 0, 3) . ' ' .
        substr($soloNumeri, 3, 3) . ' ' .
        substr($soloNumeri, 6, 4);
}

// Normalizza gli spazi dell'indirizzo
function normalizzaIndirizzo($indirizzo)
{
    $indirizzo = trim($indirizzo);

    if ($indirizzo === '') {
        return '';
    }

    $parti = array_map('trim', explode(',', $indirizzo));

    if (count($parti) !== 3) {
        return preg_replace('/\s+/', ' ', $indirizzo);
    }

    $viaComune = preg_replace('/\s+/', ' ', $parti[0]);
    $civico = preg_replace('/\s+/', '', $parti[1]);
    $capComune = preg_replace('/\s+/', ' ', $parti[2]);

    return $viaComune . ', ' . $civico . ', ' . $capComune;
}

// Verifica che l'indirizzo rispetti il formato Via Roma, 15, 20100 Milano
function indirizzoValido($indirizzo)
{
    $indirizzo = normalizzaIndirizzo($indirizzo);

    $pattern = '/^' .
        '.+,' .
        '\s*\d+[A-Za-z]?(?:[\/-][A-Za-z0-9]+)?,' .
        '\s*\d{5}\s+' .
        '[A-Za-zÀ-ÖØ-öø-ÿ\'\-\s]+$' .
        '/u';

    return preg_match($pattern, trim($indirizzo)) === 1;
}

// Calcola l'eta' in anni compiuti a partire da una data Y-m-d
function calcolaEta($dataNascita)
{
    $nascita = DateTime::createFromFormat('!Y-m-d', $dataNascita);
    $oggi = new DateTime('today');

    return $nascita->diff($oggi)->y;
}

// Recupera il codice del cliente dall'URL o dal form
$codice = trim($_GET['codice'] ?? $_POST['codice'] ?? '');
$modifica = $codice !== '';

// Aggiorna il titolo quando si modifica un cliente
$titoloPagina = 'DualCore Palestra - ' . ($modifica ? 'Modifica Cliente' : 'Nuovo Cliente');

// Inizializza i valori del form
$valori = [
    'nome' => '',
    'cognome' => '',
    'cf' => '',
    'dataNas' => '',
    'indirizzo' => '',
    'tel' => '',
    'email' => '',
];

$erroriCampi = [];
$errore = '';

// Carica i dati del cliente quando si apre la pagina di modifica
if ($modifica && $_SERVER['REQUEST_METHOD'] === 'GET') {
    try {
        $stmt = $pdo->prepare(
            'SELECT * FROM Cliente WHERE codice = ?'
        );

        $stmt->execute([$codice]);
        $riga = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$riga) {
            header('Location: clienti.php');
            exit;
        }

        $valori = [
            'nome' => $riga['nome'],
            'cognome' => $riga['cognome'],
            'cf' => $riga['cf'],
            'dataNas' => preparaDataPerInput($riga['dataNas']),
            'indirizzo' => $riga['indirizzo'],
            'tel' => $riga['tel'],
            'email' => $riga['email'],
        ];
    } catch (PDOException $e) {
        $errore = 'Impossibile recuperare i dati del cliente da modificare.';
    }
}

// Gestisce il salvataggio del nuovo cliente o delle modifiche
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Recupera e pulisce i valori inviati dal form
    foreach ($valori as $campo => $valoreVuoto) {
        $valori[$campo] = trim($_POST[$campo] ?? '');
    }

    // Controlla il nome
    if ($valori['nome'] === '') {
        $erroriCampi['nome'] = 'Il nome è obbligatorio.';
    } elseif (!nomeCognomeValido($valori['nome'])) {
        $erroriCampi['nome'] =
            'Il nome può contenere solo lettere, spazi, apostrofi e trattini.';
    }

    // Controlla il cognome
    if ($valori['cognome'] === '') {
        $erroriCampi['cognome'] = 'Il cognome è obbligatorio.';
    } elseif (!nomeCognomeValido($valori['cognome'])) {
        $erroriCampi['cognome'] =
            'Il cognome può contenere solo lettere, spazi, apostrofi e trattini.';
    }

    // Controlla il codice fiscale
    if ($valori['cf'] === '') {
        $erroriCampi['cf'] = 'Il codice fiscale è obbligatorio.';
    } elseif (strlen($valori['cf']) !== 16) {
        $erroriCampi['cf'] = 'Il codice fiscale deve essere di 16 caratteri.';
    } else {
        // Controlla che il codice fiscale non appartenga già a un altro cliente
        try {
            $stmtCf = $pdo->prepare(
                'SELECT codice FROM Cliente WHERE cf = ? AND codice != ?'
            );
            $stmtCf->execute([$valori['cf'], $codice]);

            if ($stmtCf->fetch()) {
                $erroriCampi['cf'] =
                    'Esiste già un cliente con questo codice fiscale. Inserirne uno diverso.';
            }
        } catch (PDOException $e) {
            $erroriCampi['cf'] = 'Impossibile verificare il codice fiscale. Riprova.';
        }
    }

    // Controlla la data di nascita
    $data = DateTime::createFromFormat('!Y-m-d', $valori['dataNas']);

    if (
        $valori['dataNas'] === '' ||
        $data === false ||
        $data->format('Y-m-d') !== $valori['dataNas']
    ) {
        $erroriCampi['dataNas'] = 'Inserire una data di nascita valida nel formato gg/mm/aaaa.';
    } elseif ($data > new DateTime('today')) {
        $erroriCampi['dataNas'] = 'La data di nascita non può essere futura.';
    } elseif (calcolaEta($valori['dataNas']) < 18) {
        $erroriCampi['dataNas'] = 'Il cliente deve avere almeno 18 anni.';
    }

    // Controlla e normalizza l'indirizzo
    if ($valori['indirizzo'] === '') {
        $erroriCampi['indirizzo'] = "L'indirizzo è obbligatorio.";
    } else {
        $indirizzoNormalizzato = normalizzaIndirizzo($valori['indirizzo']);

        if (!indirizzoValido($indirizzoNormalizzato)) {
            $erroriCampi['indirizzo'] =
                'Inserire un indirizzo nel formato corretto, ad esempio: Via Roma, 15, 20100 Milano.';
        } else {
            $valori['indirizzo'] = $indirizzoNormalizzato;
        }
    }

    // Controlla e formatta il telefono, accettando anche numeri scritti senza + o senza spazi
    $telefonoFormattato = formattaTelefono($valori['tel']);

    if ($valori['tel'] === '') {
        $erroriCampi['tel'] = 'Il numero di telefono è obbligatorio.';
    } elseif ($telefonoFormattato === false) {
        $erroriCampi['tel'] =
            'Formato non valido. Inserire un cellulare italiano, ad esempio: 3333336666 oppure +39 333 333 6666.';
    } else {
        $valori['tel'] = $telefonoFormattato;
    }

    // Controlla il formato dell'indirizzo email
    if ($valori['email'] === '') {
        $erroriCampi['email'] = "L'email è obbligatoria.";
    } elseif (!filter_var($valori['email'], FILTER_VALIDATE_EMAIL)) {
        $erroriCampi['email'] =
            'Formato non valido. Inserire un indirizzo email, ad esempio: nome@esempio.it.';
    }

    // Salva i dati solo se tutti i controlli sono superati
    if (empty($erroriCampi)) {
        $dataNasPerDb = $valori['dataNas'];

        try {
            if ($modifica) {
                // Aggiorna i dati del cliente esistente
                $stmt = $pdo->prepare(
                    'UPDATE Cliente
                     SET nome = ?,
                         cognome = ?,
                         cf = ?,
                         dataNas = ?,
                         indirizzo = ?,
                         tel = ?,
                         email = ?
                     WHERE codice = ?'
                );

                $stmt->execute([
                    $valori['nome'],
                    $valori['cognome'],
                    $valori['cf'],
                    $dataNasPerDb,
                    $valori['indirizzo'],
                    $valori['tel'],
                    $valori['email'],
                    $codice,
                ]);

                header('Location: clienti.php?aggiornato=1');
                exit;
            } else {
                // Inserisce un nuovo cliente
                $stmt = $pdo->prepare(
                    'INSERT INTO Cliente
                     (nome, cognome, cf, dataNas, indirizzo, tel, email)
                     VALUES (?, ?, ?, ?, ?, ?, ?)'
                );

                $stmt->execute([
                    $valori['nome'],
                    $valori['cognome'],
                    $valori['cf'],
                    $dataNasPerDb,
                    $valori['indirizzo'],
                    $valori['tel'],
                    $valori['email'],
                ]);

                header('Location: clienti.php?creato=1');
                exit;
            }
        } catch (PDOException $e) {
            // Gestisce il caso di codice fiscale già presente
            if ($e->getCode() === '23000') {
                $errore = 'Esiste già un cliente con questo codice fiscale.';
            } else {
                $errore = 'Non è stato possibile salvare i dati. Riprova più tardi.';
            }
        }
    }
}

// Include l'intestazione comune
require_once __DIR__ . '/../includes/header.php';
?>

<main class="corpo">

  <!-- Colonna laterale con solo il collegamento alla lista clienti -->
  <aside class="area-laterale">
    <section class="pannello-laterale">
      <a class="breadcrumb" href="clienti.php">&larr; Torna alla lista clienti</a>
    </section>
  </aside>

  <!-- Area centrale con il form di inserimento o modifica -->
  <section class="area-contenuto">

    <h2><?= $modifica ? 'Modifica Cliente' : 'Nuovo Cliente' ?></h2>

    <!-- Mostra eventuali errori generali -->
    <?php if ($errore !== ''): ?>
      <p class="msg-errore"><?= htmlspecialchars($errore) ?></p>
    <?php endif; ?>

    <!-- Mostra un avviso se alcuni campi non sono validi -->
    <?php if (!empty($erroriCampi)): ?>
      <p class="msg-errore">
        Controlla i campi evidenziati e correggi gli errori indicati.
      </p>
    <?php endif; ?>

    <!-- Form per creare o modificare un cliente -->
    <form method="post" action="cliente_form.php" class="form-scheda" novalidate>

      <!-- Mantiene il codice del cliente durante la modifica -->
      <?php if ($modifica): ?>
        <input type="hidden" name="codice" value="<?= htmlspecialchars($codice) ?>">
      <?php endif; ?>

      <label>
        Nome
        <input
          type="text"
          name="nome"
          value="<?= htmlspecialchars($valori['nome']) ?>"
          pattern="[A-Za-zÀ-ÖØ-öø-ÿ' -]+"
          title="Il nome può contenere solo lettere, spazi, apostrofi e trattini."
          required
        >

        <?php if (isset($erroriCampi['nome'])): ?>
          <small class="errore-campo">
            <?= htmlspecialchars($erroriCampi['nome']) ?>
          </small>
        <?php endif; ?>
      </label>

      <label>
        Cognome
        <input
          type="text"
          name="cognome"
          value="<?= htmlspecialchars($valori['cognome']) ?>"
          pattern="[A-Za-zÀ-ÖØ-öø-ÿ' -]+"
          title="Il cognome può contenere solo lettere, spazi, apostrofi e trattini."
          required
        >

        <?php if (isset($erroriCampi['cognome'])): ?>
          <small class="errore-campo">
            <?= htmlspecialchars($erroriCampi['cognome']) ?>
          </small>
        <?php endif; ?>
      </label>

      <label>
        Codice Fiscale
        <input
          type="text"
          name="cf"
          value="<?= htmlspecialchars($valori['cf']) ?>"
          maxlength="16"
          required
        >

        <?php if (isset($erroriCampi['cf'])): ?>
          <small class="errore-campo">
            <?= htmlspecialchars($erroriCampi['cf']) ?>
          </small>
        <?php endif; ?>
      </label>

      <label>
        Data di nascita
        <input
          type="date"
          name="dataNas"
          value="<?= htmlspecialchars($valori['dataNas']) ?>"
          max="<?= (new DateTime('today'))->format('Y-m-d') ?>"
          required
        >

        <?php if (isset($erroriCampi['dataNas'])): ?>
          <small class="errore-campo">
            <?= htmlspecialchars($erroriCampi['dataNas']) ?>
          </small>
        <?php endif; ?>
      </label>

      <label>
        Telefono
        <input
          type="tel"
          name="tel"
          value="<?= htmlspecialchars($valori['tel']) ?>"
          required
        >

        <?php if (isset($erroriCampi['tel'])): ?>
          <small class="errore-campo">
            <?= htmlspecialchars($erroriCampi['tel']) ?>
          </small>
        <?php endif; ?>
      </label>

      <label>
        Email
        <input
          type="email"
          name="email"
          value="<?= htmlspecialchars($valori['email']) ?>"
          required
        >

        <?php if (isset($erroriCampi['email'])): ?>
          <small class="errore-campo">
            <?= htmlspecialchars($erroriCampi['email']) ?>
          </small>
        <?php endif; ?>
      </label>

      <label class="campo-esteso">
        Indirizzo
        <input
          type="text"
          name="indirizzo"
          value="<?= htmlspecialchars($valori['indirizzo']) ?>"
          required
        >

        <?php if (isset($erroriCampi['indirizzo'])): ?>
          <small class="errore-campo">
            <?= htmlspecialchars($erroriCampi['indirizzo']) ?>
          </small>
        <?php endif; ?>
      </label>

      <!-- Pulsanti per inviare o annullare il form -->
      <div class="form-azioni campo-esteso">
        <button type="submit" class="btn">
          <?= $modifica ? 'Salva modifiche' : 'Registra cliente' ?>
        </button>

        <a class="btn-secondario" href="clienti.php">Annulla</a>
      </div>

    </form>
  </section>

  <!-- Include il menu comune -->
  <?php require_once __DIR__ . '/../includes/nav.php'; ?>

</main>

<!-- Include il footer comune -->
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

</body>
</html>