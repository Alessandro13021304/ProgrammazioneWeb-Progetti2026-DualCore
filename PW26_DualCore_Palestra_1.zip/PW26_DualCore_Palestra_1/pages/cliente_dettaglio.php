<?php

// Connessione al database
require_once __DIR__ . '/../config/database.php';

// Percorso base e titolo pagina
$basePath = '../';
$titoloPagina = 'DualCore Palestra - Dettaglio Cliente';

// Formatta una data testuale GG/MM/AAAA
function formattaDataIt(?string $data): string
{
    if ($data === null || trim($data) === '') {
        return '';
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Mostra l'orario come HH:MM
function formattaOra(?string $ora): string
{
    if ($ora === null || trim($ora) === '') {
        return '';
    }
    return htmlspecialchars(substr(trim($ora), 0, 5), ENT_QUOTES, 'UTF-8');
}

// Codice cliente ricevuto dall'URL
$codice = trim($_GET['codice'] ?? '');

// Torna alla lista se manca il codice
if ($codice === '') {
    header('Location: clienti.php');
    exit;
}

// Variabili della pagina
$cliente = null;
$abbonamenti = [];
$prenotazioni = [];
$errore = '';

try {
    // Recupera i dati anagrafici del cliente
    $stmtC = $pdo->prepare('SELECT * FROM Cliente WHERE codice = ?');
    $stmtC->execute([$codice]);
    $cliente = $stmtC->fetch(PDO::FETCH_ASSOC);

    // Torna alla lista se il cliente non esiste
    if (!$cliente) {
        header('Location: clienti.php');
        exit;
    }

    // Recupera gli abbonamenti del cliente e calcola il loro stato
    // Le date sono salvate come testo GG/MM/AAAA, quindi si usa STR_TO_DATE
    $stmtA = $pdo->prepare(
        "SELECT
            nAbb,
            inizio,
            fine,
            prezzo,
            CASE
                WHEN CURDATE() < STR_TO_DATE(inizio, '%d/%m/%Y') THEN 'Futuro'
                WHEN CURDATE() BETWEEN STR_TO_DATE(inizio, '%d/%m/%Y')
                    AND STR_TO_DATE(fine, '%d/%m/%Y') THEN 'Attivo'
                ELSE 'Scaduto'
            END AS stato
         FROM Abbonamento
         WHERE cliente = ?
         ORDER BY STR_TO_DATE(inizio, '%d/%m/%Y') DESC"
    );
    $stmtA->execute([$codice]);
    $abbonamenti = $stmtA->fetchAll(PDO::FETCH_ASSOC);

    // Recupera le prenotazioni del cliente e il relativo tipo
    $stmtP = $pdo->prepare(
        "SELECT
            p.nProg,
            p.sala,
            p.data,
            p.ora,
            p.posto,
            s.nome AS sala_nome,
            sa.abbonamento AS numero_abbonamento,
            CASE
                WHEN sa.prenotazione IS NOT NULL THEN 'Sub Abbonamento'
                ELSE 'Semplice'
            END AS tipo
         FROM Prenotazione p
         JOIN Sala s ON s.codice = p.sala
         LEFT JOIN SubAbbonamento sa ON sa.prenotazione = p.nProg
         WHERE p.cliente = ?
         ORDER BY STR_TO_DATE(p.data, '%d/%m/%Y') DESC, p.ora DESC"
    );
    $stmtP->execute([$codice]);
    $prenotazioni = $stmtP->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    $errore = 'Errore nel caricamento dei dati. Riprova piu tardi.';
}

// Include header e CSS
require_once __DIR__ . '/../includes/header.php';

?>

<main class="corpo">

    <!-- Colonna sinistra: navigazione e azioni sul cliente -->
    <aside class="area-laterale">

        <section class="pannello-laterale">

            <a class="breadcrumb" href="clienti.php">
                &larr; Torna alla lista clienti
            </a>

            <h3>Azioni</h3>

            <a class="link-azione" href="cliente_form.php?codice=<?= urlencode($codice) ?>">
                Modifica cliente
            </a>

            <a class="link-azione" href="cliente_elimina.php?codice=<?= urlencode($codice) ?>">
                Elimina cliente
            </a>

        </section>

    </aside>

    <!-- Area centrale con dati, abbonamenti e prenotazioni del cliente -->
    <section class="area-contenuto">

        <?php if ($errore !== ''): ?>

            <p class="msg-errore">
                <?= htmlspecialchars($errore, ENT_QUOTES, 'UTF-8') ?>
            </p>

        <?php elseif ($cliente): ?>

            <h2>
                <?= htmlspecialchars($cliente['nome'] . ' ' . $cliente['cognome'], ENT_QUOTES, 'UTF-8') ?>
            </h2>

            <!-- Scheda con i dati anagrafici -->
            <div class="scheda">

                <div class="scheda-campo">
                    <label>Nome</label>
                    <span><?= htmlspecialchars($cliente['nome'], ENT_QUOTES, 'UTF-8') ?></span>
                </div>

                <div class="scheda-campo">
                    <label>Cognome</label>
                    <span><?= htmlspecialchars($cliente['cognome'], ENT_QUOTES, 'UTF-8') ?></span>
                </div>

                <div class="scheda-campo">
                    <label>Codice Fiscale</label>
                    <span><?= htmlspecialchars($cliente['cf'], ENT_QUOTES, 'UTF-8') ?></span>
                </div>

                <div class="scheda-campo">
                    <label>Data di nascita</label>
                    <span><?= formattaDataIt($cliente['dataNas']) ?></span>
                </div>

                <div class="scheda-campo">
                    <label>Telefono</label>
                    <span>
                        <a href="tel:<?= htmlspecialchars($cliente['tel'], ENT_QUOTES, 'UTF-8') ?>">
                            <?= htmlspecialchars($cliente['tel'], ENT_QUOTES, 'UTF-8') ?>
                        </a>
                    </span>
                </div>

                <div class="scheda-campo">
                    <label>Email</label>
                    <span>
                        <a href="mailto:<?= htmlspecialchars($cliente['email'], ENT_QUOTES, 'UTF-8') ?>">
                            <?= htmlspecialchars($cliente['email'], ENT_QUOTES, 'UTF-8') ?>
                        </a>
                    </span>
                </div>

                <div class="scheda-campo">
                    <label>Indirizzo</label>
                    <span><?= htmlspecialchars($cliente['indirizzo'], ENT_QUOTES, 'UTF-8') ?></span>
                </div>

            </div>

            <!-- Sezione degli abbonamenti del cliente -->
            <h2 id="abbonamenti" class="sezione-anchor">
                Abbonamenti
                <small style="font-size:.75rem;font-weight:400;color:var(--muted);margin-left:.5rem;">
                    <?= count($abbonamenti) ?>
                </small>
            </h2>

            <?php if (empty($abbonamenti)): ?>

                <p class="msg-avviso">
                    Nessun abbonamento registrato per questo cliente.
                </p>

            <?php else: ?>

                <!-- Tabella degli abbonamenti -->
                <section class="contenuto-risultati" style="margin-bottom:2rem;">

                    <table class="tabella">
                        <thead>
                            <tr>
                                <th>N. Abb.</th>
                                <th>Inizio</th>
                                <th>Fine</th>
                                <th>Prezzo</th>
                                <th>Stato</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php foreach ($abbonamenti as $a): ?>

                                <tr>

                                    <td data-label="N. Abb.">
                                        <a href="abbonamento_dettaglio.php?nAbb=<?= urlencode($a['nAbb']) ?>">
                                            #<?= htmlspecialchars((string) $a['nAbb'], ENT_QUOTES, 'UTF-8') ?>
                                        </a>
                                    </td>

                                    <td data-label="Inizio">
                                        <?= formattaDataIt($a['inizio']) ?>
                                    </td>

                                    <td data-label="Fine">
                                        <?= formattaDataIt($a['fine']) ?>
                                    </td>

                                    <td data-label="Prezzo">
                                        &euro; <?= number_format((float) $a['prezzo'], 2, ',', '.') ?>
                                    </td>

                                    <td data-label="Stato">

                                        <?php if ($a['stato'] === 'Attivo'): ?>
                                            <span class="badge badge-attivo">Attivo</span>
                                        <?php elseif ($a['stato'] === 'Futuro'): ?>
                                            <span class="badge badge-futuro">Futuro</span>
                                        <?php else: ?>
                                            <span class="badge badge-scaduto">Scaduto</span>
                                        <?php endif; ?>

                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>
                    </table>

                </section>

            <?php endif; ?>

            <!-- Sezione delle prenotazioni del cliente -->
            <h2 id="prenotazioni" class="sezione-anchor">
                Prenotazioni
                <small style="font-size:.75rem;font-weight:400;color:var(--muted);margin-left:.5rem;">
                    <?= count($prenotazioni) ?>
                </small>
            </h2>

            <?php if (empty($prenotazioni)): ?>

                <p class="msg-avviso">
                    Nessuna prenotazione registrata per questo cliente.
                </p>

            <?php else: ?>

                <!-- Tabella delle prenotazioni -->
                <section class="contenuto-risultati">

                    <table class="tabella">
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Ora</th>
                                <th>Sala</th>
                                <th>Posto</th>
                                <th>Tipo</th>
                                <th>Abbonamento</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php foreach ($prenotazioni as $p): ?>

                                <?php
                                // Link alla fascia oraria della prenotazione
                                $urlFascia = 'fasciaoraria.php?' . http_build_query([
                                    'sala' => $p['sala'],
                                    'data' => $p['data'],
                                    'ora' => substr($p['ora'], 0, 5)
                                ]);

                                // Link al dettaglio del posto prenotato
                                $urlPosto = 'posto.php?' . http_build_query([
                                    'sala' => $p['sala'],
                                    'data' => $p['data'],
                                    'ora' => substr($p['ora'], 0, 5),
                                    'posto' => $p['posto']
                                ]);
                                ?>

                                <tr>

                                    <td data-label="Data">
                                        <?= formattaDataIt($p['data']) ?>
                                    </td>

                                    <td data-label="Ora">
                                        <a href="<?= htmlspecialchars($urlFascia, ENT_QUOTES, 'UTF-8') ?>">
                                            <?= formattaOra($p['ora']) ?>
                                        </a>
                                    </td>

                                    <td data-label="Sala">
                                        <a href="sala_dettaglio.php?codice=<?= urlencode($p['sala']) ?>">
                                            <?= htmlspecialchars($p['sala_nome'], ENT_QUOTES, 'UTF-8') ?>
                                        </a>
                                    </td>

                                    <td data-label="Posto">
                                        <a href="<?= htmlspecialchars($urlPosto, ENT_QUOTES, 'UTF-8') ?>">
                                            <?= htmlspecialchars((string) $p['posto'], ENT_QUOTES, 'UTF-8') ?>
                                        </a>
                                    </td>

                                    <td data-label="Tipo">
                                        <span class="tag-tipo <?= $p['tipo'] === 'Sub Abbonamento' ? 'tag-abbonamento' : 'tag-semplice' ?>">
                                            <?= htmlspecialchars($p['tipo'], ENT_QUOTES, 'UTF-8') ?>
                                        </span>
                                    </td>

                                    <td data-label="Abbonamento">
                                        <?php if ($p['numero_abbonamento'] !== null): ?>
                                            <a href="abbonamento_dettaglio.php?nAbb=<?= urlencode($p['numero_abbonamento']) ?>">
                                                #<?= htmlspecialchars((string) $p['numero_abbonamento'], ENT_QUOTES, 'UTF-8') ?>
                                            </a>
                                        <?php else: ?>
                                            <span class="nessuno">-</span>
                                        <?php endif; ?>
                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>
                    </table>

                </section>

            <?php endif; ?>

        <?php endif; ?>

    </section>

    <!-- Menu laterale destro -->
    <?php require_once __DIR__ . '/../includes/nav.php'; ?>

</main>

<!-- Footer -->
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

</body>
</html>