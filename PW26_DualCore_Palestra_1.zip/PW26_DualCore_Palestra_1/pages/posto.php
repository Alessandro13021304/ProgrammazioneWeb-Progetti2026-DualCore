<?php

// Connessione al database
require_once __DIR__ . '/../config/database.php';

// Percorso base e titolo pagina
$basePath = '../';
$titoloPagina = 'DualCore Palestra - Dettaglio posto';

// Formatta una data testuale GG/MM/AAAA
function formattaDataIt(?string $data): string
{
    if ($data === null || trim($data) === '') {
        return '';
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Mostra l'orario come HH:MM
function formattaOra(?string $ora): string
{
    if ($ora === null || trim($ora) === '') {
        return '';
    }
    return htmlspecialchars(substr(trim($ora), 0, 5), ENT_QUOTES, 'UTF-8');
}

// Converte una data in formato ISO, qualunque sia il formato di arrivo
function convertiDataIso(string $data): string
{
    $data = trim($data);

    if ($data === '') {
        return '';
    }

    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) {
        return $data;
    }

    $dt = DateTime::createFromFormat('d/m/Y', $data);

    if ($dt !== false) {
        return $dt->format('Y-m-d');
    }

    return $data;
}

// Controlla il formato dell'orario
function oraValida(string $ora): bool
{
    return (bool) preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $ora);
}

// Parametri della chiave composta del posto
$codiceSala = trim($_GET['sala'] ?? '');
$data = convertiDataIso(trim($_GET['data'] ?? ''));
$ora = trim($_GET['ora'] ?? '');
$numeroPosto = trim($_GET['posto'] ?? '');

// Torna alle sale se i parametri non sono validi
if (
    $codiceSala === ''
    || !ctype_digit($codiceSala)
    || $data === ''
    || DateTime::createFromFormat('Y-m-d', $data) === false
    || $ora === ''
    || !oraValida($ora)
    || $numeroPosto === ''
    || !ctype_digit($numeroPosto)
) {
    header('Location: sale.php');
    exit;
}

// Variabili della pagina
$posto = null;
$errore = '';

try {
    // Cerca il posto insieme a sala, fascia, prenotazione e cliente
    // La colonna data e' testo GG/MM/AAAA, quindi si usa STR_TO_DATE
    $stmtPosto = $pdo->prepare(
        "SELECT
            p.sala,
            p.data,
            p.ora,
            p.nProg AS numero_posto,

            s.codice AS codice_sala,
            s.nome AS nome_sala,
            s.tema AS tema_sala,

            fo.durata AS durata_fascia,

            pr.nProg AS numero_prenotazione,
            pr.data AS data_prenotazione,
            pr.ora AS ora_prenotazione,
            pr.cliente AS codice_cliente,

            c.nome AS nome_cliente,
            c.cognome AS cognome_cliente,
            c.email AS email_cliente,
            c.tel AS telefono_cliente,

            sa.abbonamento AS numero_abbonamento,

            CASE
                WHEN pr.nProg IS NULL THEN 'Libero'
                ELSE 'Occupato'
            END AS stato_posto,

            CASE
                WHEN pr.nProg IS NULL THEN NULL
                WHEN sa.prenotazione IS NULL THEN 'Semplice'
                ELSE 'Sub Abbonamento'
            END AS tipo_prenotazione

         FROM Posto p

         INNER JOIN Sala s
            ON s.codice = p.sala

         INNER JOIN FasciaOraria fo
            ON fo.sala = p.sala
           AND fo.data = p.data
           AND TIME_FORMAT(fo.ora, '%H:%i') = TIME_FORMAT(p.ora, '%H:%i')

         LEFT JOIN Prenotazione pr
            ON pr.sala = p.sala
           AND pr.data = p.data
           AND TIME_FORMAT(pr.ora, '%H:%i') = TIME_FORMAT(p.ora, '%H:%i')
           AND pr.posto = p.nProg

         LEFT JOIN Cliente c
            ON c.codice = pr.cliente

         LEFT JOIN SubAbbonamento sa
            ON sa.prenotazione = pr.nProg

         WHERE p.sala = :sala
           AND STR_TO_DATE(p.data, '%d/%m/%Y') = :data
           AND TIME_FORMAT(p.ora, '%H:%i') = :ora
           AND p.nProg = :posto"
    );

    $stmtPosto->execute([
        ':sala' => (int) $codiceSala,
        ':data' => $data,
        ':ora' => substr($ora, 0, 5),
        ':posto' => (int) $numeroPosto
    ]);

    $posto = $stmtPosto->fetch(PDO::FETCH_ASSOC);

    if (!$posto) {
        $errore = 'Il posto richiesto non e stato trovato.';
    }

} catch (PDOException $e) {
    $errore = 'Non e stato possibile caricare il posto. Riprova piu tardi.';
}

// Link alla fascia oraria di appartenenza
$urlFascia = 'fasciaoraria.php?' . http_build_query([
    'sala' => $codiceSala,
    'data' => $data,
    'ora' => substr($ora, 0, 5)
]);

// Include header e CSS
require_once __DIR__ . '/../includes/header.php';

?>

<main class="corpo">

    <!-- Colonna sinistra: ritorno e collegamenti -->
    <aside class="area-laterale">

        <section class="pannello-laterale">

            <a
                class="breadcrumb"
                href="<?= htmlspecialchars($urlFascia, ENT_QUOTES, 'UTF-8') ?>"
            >
                &larr; Torna alla fascia oraria
            </a>

        </section>

        <?php if ($posto): ?>

            <section class="pannello-laterale">

                <h3>Collegamenti</h3>

                <a
                    class="link-azione"
                    href="sala_dettaglio.php?codice=<?= urlencode($posto['codice_sala']) ?>"
                >
                    Dettaglio sala
                </a>

                <?php if ($posto['codice_cliente'] !== null): ?>

                    <a
                        class="link-azione"
                        href="cliente_dettaglio.php?codice=<?= urlencode($posto['codice_cliente']) ?>"
                    >
                        Scheda cliente
                    </a>

                <?php endif; ?>

                <?php if ($posto['numero_abbonamento'] !== null): ?>

                    <a
                        class="link-azione"
                        href="abbonamento_dettaglio.php?nAbb=<?= urlencode($posto['numero_abbonamento']) ?>"
                    >
                        Scheda abbonamento
                    </a>

                <?php endif; ?>

            </section>

        <?php endif; ?>

    </aside>

    <!-- Contenuto centrale -->
    <section class="area-contenuto">

        <?php if ($errore !== ''): ?>

            <p class="msg-errore">
                <?= htmlspecialchars($errore, ENT_QUOTES, 'UTF-8') ?>
            </p>

        <?php elseif ($posto): ?>

            <h2>
                Posto <?= htmlspecialchars((string) $posto['numero_posto'], ENT_QUOTES, 'UTF-8') ?>
                -
                <?= htmlspecialchars($posto['nome_sala'], ENT_QUOTES, 'UTF-8') ?>
            </h2>

            <!-- Dati del posto e della fascia -->
            <section class="scheda">

                <div class="scheda-campo">
                    <label>Sala</label>
                    <span>
                        <a href="sala_dettaglio.php?codice=<?= urlencode($posto['codice_sala']) ?>">
                            <?= htmlspecialchars($posto['nome_sala'], ENT_QUOTES, 'UTF-8') ?>
                        </a>
                    </span>
                </div>

                <div class="scheda-campo">
                    <label>Tema</label>
                    <span><?= htmlspecialchars($posto['tema_sala'], ENT_QUOTES, 'UTF-8') ?></span>
                </div>

                <div class="scheda-campo">
                    <label>Data</label>
                    <span><?= formattaDataIt($posto['data']) ?></span>
                </div>

                <div class="scheda-campo">
                    <label>Ora</label>
                    <span><?= formattaOra($posto['ora']) ?></span>
                </div>

                <div class="scheda-campo">
                    <label>Durata fascia</label>
                    <span><?= htmlspecialchars((string) $posto['durata_fascia'], ENT_QUOTES, 'UTF-8') ?> min</span>
                </div>

                <div class="scheda-campo">
                    <label>Numero posto</label>
                    <span><?= htmlspecialchars((string) $posto['numero_posto'], ENT_QUOTES, 'UTF-8') ?></span>
                </div>

                <div class="scheda-campo">
                    <label>Stato</label>
                    <span>

                        <?php if ($posto['stato_posto'] === 'Occupato'): ?>
                            <span class="badge badge-scaduto">Occupato</span>
                        <?php else: ?>
                            <span class="badge badge-attivo">Libero</span>
                        <?php endif; ?>

                    </span>
                </div>

            </section>

            <h2 class="sezione-anchor">Prenotazione</h2>

            <?php if ($posto['numero_prenotazione'] === null): ?>

                <p class="msg-avviso">
                    Questo posto e libero: non e presente alcuna prenotazione.
                </p>

            <?php else: ?>

                <!-- Dati della prenotazione collegata -->
                <section class="scheda">

                    <div class="scheda-campo">
                        <label>Numero prenotazione</label>
                        <span>#<?= htmlspecialchars((string) $posto['numero_prenotazione'], ENT_QUOTES, 'UTF-8') ?></span>
                    </div>

                    <div class="scheda-campo">
                        <label>Data prenotazione</label>
                        <span><?= formattaDataIt($posto['data_prenotazione']) ?></span>
                    </div>

                    <div class="scheda-campo">
                        <label>Ora prenotazione</label>
                        <span><?= formattaOra($posto['ora_prenotazione']) ?></span>
                    </div>

                    <div class="scheda-campo">
                        <label>Tipo</label>
                        <span>

                            <?php if ($posto['tipo_prenotazione'] === 'Sub Abbonamento'): ?>
                                <span class="tag-tipo tag-abbonamento">Sub Abbonamento</span>
                            <?php else: ?>
                                <span class="tag-tipo tag-semplice">Semplice</span>
                            <?php endif; ?>

                        </span>
                    </div>

                    <div class="scheda-campo">
                        <label>Cliente</label>
                        <span>
                            <a
                                class="link-cliente"
                                href="cliente_dettaglio.php?codice=<?= urlencode($posto['codice_cliente']) ?>"
                            >
                                <?= htmlspecialchars(
                                    $posto['nome_cliente'] . ' ' . $posto['cognome_cliente'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>
                            </a>
                        </span>
                    </div>

                    <div class="scheda-campo">
                        <label>Email</label>
                        <span>
                            <a href="mailto:<?= htmlspecialchars($posto['email_cliente'], ENT_QUOTES, 'UTF-8') ?>">
                                <?= htmlspecialchars($posto['email_cliente'], ENT_QUOTES, 'UTF-8') ?>
                            </a>
                        </span>
                    </div>

                    <div class="scheda-campo">
                        <label>Telefono</label>
                        <span>
                            <a href="tel:<?= htmlspecialchars($posto['telefono_cliente'], ENT_QUOTES, 'UTF-8') ?>">
                                <?= htmlspecialchars($posto['telefono_cliente'], ENT_QUOTES, 'UTF-8') ?>
                            </a>
                        </span>
                    </div>

                    <?php if ($posto['numero_abbonamento'] !== null): ?>

                        <div class="scheda-campo">
                            <label>Abbonamento usato</label>
                            <span>
                                <a href="abbonamento_dettaglio.php?nAbb=<?= urlencode($posto['numero_abbonamento']) ?>">
                                    #<?= htmlspecialchars((string) $posto['numero_abbonamento'], ENT_QUOTES, 'UTF-8') ?>
                                </a>
                            </span>
                        </div>

                    <?php endif; ?>

                </section>

            <?php endif; ?>

        <?php endif; ?>

    </section>

    <!-- Menu laterale destro -->
    <?php require_once __DIR__ . '/../includes/nav.php'; ?>

</main>

<!-- Footer -->
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

</body>
</html>