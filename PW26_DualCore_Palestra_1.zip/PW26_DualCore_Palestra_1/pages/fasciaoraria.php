<?php

// Connessione al database
require_once __DIR__ . '/../config/database.php';

// Percorso base e titolo pagina
$basePath = '../';
$titoloPagina = 'DualCore Palestra - Fascia oraria';

// Formatta una data testuale GG/MM/AAAA
function formattaDataIt(?string $data): string
{
    if ($data === null || trim($data) === '') {
        return '';
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Mostra l'orario come HH:MM
function formattaOra(?string $ora): string
{
    if ($ora === null || trim($ora) === '') {
        return '';
    }
    return htmlspecialchars(substr(trim($ora), 0, 5), ENT_QUOTES, 'UTF-8');
}

// Converte una data in formato ISO, qualunque sia il formato di arrivo
function convertiDataIso(string $data): string
{
    $data = trim($data);

    if ($data === '') {
        return '';
    }

    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) {
        return $data;
    }

    $dt = DateTime::createFromFormat('d/m/Y', $data);

    if ($dt !== false) {
        return $dt->format('Y-m-d');
    }

    return $data;
}

// Controlla che l'orario sia in formato HH:MM oppure HH:MM:SS
function oraValida(string $ora): bool
{
    return (bool) preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $ora);
}

// Parametri della chiave composta della fascia
$codiceSala = trim($_GET['sala'] ?? '');
$data = convertiDataIso(trim($_GET['data'] ?? ''));
$ora = trim($_GET['ora'] ?? '');

if (
    $codiceSala === ''
    || !ctype_digit($codiceSala)
    || $data === ''
    || DateTime::createFromFormat('Y-m-d', $data) === false
    || $ora === ''
    || !oraValida($ora)
) {
    header('Location: sale.php');
    exit;
}

$fascia = null;
$posti = [];
$errore = '';

$postiTotali = 0;
$postiOccupati = 0;
$postiDisponibili = 0;

try {
    $stmtFascia = $pdo->prepare(
        "SELECT
            fo.sala,
            fo.data,
            fo.ora,
            fo.durata,
            s.codice AS codice_sala,
            s.nome AS nome_sala,
            s.tema AS tema_sala,
            s.mq AS mq_sala
         FROM FasciaOraria fo
         INNER JOIN Sala s ON s.codice = fo.sala
         WHERE fo.sala = :sala
           AND STR_TO_DATE(fo.data, '%d/%m/%Y') = :data
           AND TIME_FORMAT(fo.ora, '%H:%i') = :ora"
    );

    $stmtFascia->execute([
        ':sala' => (int) $codiceSala,
        ':data' => $data,
        ':ora' => substr($ora, 0, 5)
    ]);

    $fascia = $stmtFascia->fetch(PDO::FETCH_ASSOC);

    if (!$fascia) {
        $errore = 'La fascia oraria richiesta non e stata trovata.';
    } else {
        $stmtPosti = $pdo->prepare(
            "SELECT
                p.sala,
                p.data,
                p.ora,
                p.nProg AS numero_posto,

                pr.nProg AS numero_prenotazione,
                pr.cliente AS codice_cliente,

                c.nome AS nome_cliente,
                c.cognome AS cognome_cliente,

                sa.abbonamento AS numero_abbonamento,

                CASE
                    WHEN pr.nProg IS NULL THEN 'Libero'
                    ELSE 'Occupato'
                END AS stato_posto,

                CASE
                    WHEN pr.nProg IS NULL THEN NULL
                    WHEN sa.prenotazione IS NULL THEN 'Semplice'
                    ELSE 'Sub Abbonamento'
                END AS tipo_prenotazione

             FROM Posto p

             LEFT JOIN Prenotazione pr
                ON pr.sala = p.sala
               AND pr.data = p.data
               AND TIME_FORMAT(pr.ora, '%H:%i') = TIME_FORMAT(p.ora, '%H:%i')
               AND pr.posto = p.nProg

             LEFT JOIN Cliente c ON c.codice = pr.cliente

             LEFT JOIN SubAbbonamento sa ON sa.prenotazione = pr.nProg

             WHERE p.sala = :sala
               AND STR_TO_DATE(p.data, '%d/%m/%Y') = :data
               AND TIME_FORMAT(p.ora, '%H:%i') = :ora

             ORDER BY p.nProg ASC"
        );

        $stmtPosti->execute([
            ':sala' => (int) $codiceSala,
            ':data' => $data,
            ':ora' => substr($ora, 0, 5)
        ]);

        $posti = $stmtPosti->fetchAll(PDO::FETCH_ASSOC);

        $postiTotali = count($posti);

        foreach ($posti as $posto) {
            if ($posto['numero_prenotazione'] !== null) {
                $postiOccupati++;
            }
        }

        $postiDisponibili = $postiTotali - $postiOccupati;
    }

} catch (PDOException $e) {
    $errore = 'Non e stato possibile caricare la fascia oraria. Riprova piu tardi.';
}

require_once __DIR__ . '/../includes/header.php';

?>

<main class="corpo">

    <!-- Colonna sinistra: ritorno alla sala e collegamenti -->
    <aside class="area-laterale">

        <section class="pannello-laterale">

            <a
                class="breadcrumb"
                href="sala_dettaglio.php?codice=<?= urlencode($codiceSala) ?>"
            >
                &larr; Torna alla sala
            </a>

        </section>

        <?php if ($fascia): ?>

            <section class="pannello-laterale">

                <h3>Collegamenti</h3>

                <a
                    class="link-azione"
                    href="sala_dettaglio.php?codice=<?= urlencode($fascia['sala']) ?>"
                >
                    Dettaglio sala
                </a>

                <a
                    class="link-azione"
                    href="prenotazioni.php?sala=<?= urlencode($fascia['sala']) ?>&data_da=<?= urlencode($data) ?>&data_a=<?= urlencode($data) ?>"
                >
                    Prenotazioni della data
                </a>

            </section>

        <?php endif; ?>

    </aside>

    <!-- Contenuto centrale -->
    <section class="area-contenuto">

        <?php if ($errore !== ''): ?>

            <p class="msg-errore">
                <?= htmlspecialchars($errore, ENT_QUOTES, 'UTF-8') ?>
            </p>

        <?php elseif ($fascia): ?>

            <h2>
                Fascia oraria - <?= htmlspecialchars($fascia['nome_sala'], ENT_QUOTES, 'UTF-8') ?>
            </h2>

            <!-- Dati della fascia -->
            <section class="scheda">

                <div class="scheda-campo">
                    <label>Sala</label>
                    <span>
                        <a href="sala_dettaglio.php?codice=<?= urlencode($fascia['codice_sala']) ?>">
                            <?= htmlspecialchars($fascia['nome_sala'], ENT_QUOTES, 'UTF-8') ?>
                        </a>
                    </span>
                </div>

                <div class="scheda-campo">
                    <label>Tema</label>
                    <span><?= htmlspecialchars($fascia['tema_sala'], ENT_QUOTES, 'UTF-8') ?></span>
                </div>

                <div class="scheda-campo">
                    <label>Superficie</label>
                    <span><?= htmlspecialchars((string) $fascia['mq_sala'], ENT_QUOTES, 'UTF-8') ?> m²</span>
                </div>

                <div class="scheda-campo">
                    <label>Data</label>
                    <span><?= formattaDataIt($fascia['data']) ?></span>
                </div>

                <div class="scheda-campo">
                    <label>Ora</label>
                    <span><?= formattaOra($fascia['ora']) ?></span>
                </div>

                <div class="scheda-campo">
                    <label>Durata</label>
                    <span><?= htmlspecialchars((string) $fascia['durata'], ENT_QUOTES, 'UTF-8') ?> min</span>
                </div>

                <div class="scheda-campo">
                    <label>Posti disponibili</label>
                    <span><?= $postiDisponibili ?> su <?= $postiTotali ?></span>
                </div>

            </section>

            <h2 class="sezione-anchor">Posti della fascia</h2>

            <?php if (empty($posti)): ?>

                <p class="msg-avviso">
                    Non sono presenti posti per questa fascia oraria.
                </p>

            <?php else: ?>

                <!-- Area con scroll assistito ai bordi laterali -->
                <div class="tabella-scroll-area">

                    <div class="scroll-edge scroll-edge-left is-hidden" data-scroll-edge="left" aria-hidden="true" title="Sposta la tabella a sinistra"></div>

                    <div class="tabella-wrap" id="tabellaFasciaWrap">

                        <table class="tabella">
                            <thead>
                                <tr>
                                    <th>Posto</th>
                                    <th>Stato</th>
                                    <th>Prenotazione</th>
                                    <th>Cliente</th>
                                    <th>Tipo</th>
                                    <th>Abbonamento</th>
                                </tr>
                            </thead>

                            <tbody>

                                <?php foreach ($posti as $posto): ?>

                                    <?php
                                    // Link al dettaglio del posto
                                    $urlPosto = 'posto.php?' . http_build_query([
                                        'sala' => $posto['sala'],
                                        'data' => $posto['data'],
                                        'ora' => $posto['ora'],
                                        'posto' => $posto['numero_posto']
                                    ]);
                                    ?>

                                    <tr>

                                        <td data-label="Posto">
                                            <a href="<?= htmlspecialchars($urlPosto, ENT_QUOTES, 'UTF-8') ?>">
                                                Posto <?= htmlspecialchars((string) $posto['numero_posto'], ENT_QUOTES, 'UTF-8') ?>
                                            </a>
                                        </td>

                                        <td data-label="Stato">

                                            <?php if ($posto['stato_posto'] === 'Occupato'): ?>
                                                <span class="badge badge-scaduto">Occupato</span>
                                            <?php else: ?>
                                                <span class="badge badge-attivo">Libero</span>
                                            <?php endif; ?>

                                        </td>

                                        <td data-label="Prenotazione">

                                            <?php if ($posto['numero_prenotazione'] !== null): ?>
                                                <a href="prenotazioni.php?numero=<?= urlencode($posto['numero_prenotazione']) ?>">
                                                    #<?= htmlspecialchars((string) $posto['numero_prenotazione'], ENT_QUOTES, 'UTF-8') ?>
                                                </a>
                                            <?php else: ?>
                                                <span class="nessuno">-</span>
                                            <?php endif; ?>

                                        </td>

                                        <td data-label="Cliente">

                                            <?php if ($posto['codice_cliente'] !== null): ?>
                                                <a
                                                    class="link-cliente"
                                                    href="cliente_dettaglio.php?codice=<?= urlencode($posto['codice_cliente']) ?>"
                                                >
                                                    <?= htmlspecialchars(
                                                        $posto['nome_cliente'] . ' ' . $posto['cognome_cliente'],
                                                        ENT_QUOTES,
                                                        'UTF-8'
                                                    ) ?>
                                                </a>
                                            <?php else: ?>
                                                <span class="nessuno">-</span>
                                            <?php endif; ?>

                                        </td>

                                        <td data-label="Tipo">

                                            <?php if ($posto['tipo_prenotazione'] === 'Sub Abbonamento'): ?>
                                                <span class="tag-tipo tag-abbonamento">Sub Abbonamento</span>
                                            <?php elseif ($posto['tipo_prenotazione'] === 'Semplice'): ?>
                                                <span class="tag-tipo tag-semplice">Semplice</span>
                                            <?php else: ?>
                                                <span class="nessuno">-</span>
                                            <?php endif; ?>

                                        </td>

                                        <td data-label="Abbonamento">

                                            <?php if ($posto['numero_abbonamento'] !== null): ?>
                                                <a href="abbonamento_dettaglio.php?nAbb=<?= urlencode($posto['numero_abbonamento']) ?>">
                                                    #<?= htmlspecialchars((string) $posto['numero_abbonamento'], ENT_QUOTES, 'UTF-8') ?>
                                                </a>
                                            <?php else: ?>
                                                <span class="nessuno">-</span>
                                            <?php endif; ?>

                                        </td>

                                    </tr>

                                <?php endforeach; ?>

                            </tbody>
                        </table>

                    </div>

                    <div class="scroll-edge scroll-edge-right" data-scroll-edge="right" aria-hidden="true" title="Sposta la tabella a destra"></div>

                </div>

            <?php endif; ?>

        <?php endif; ?>

    </section>

    <!-- Menu laterale destro -->
    <?php require_once __DIR__ . '/../includes/nav.php'; ?>

</main>

<!-- Footer -->
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<!-- Gestisce lo scroll automatico ai bordi della tabella -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    const wrap = document.getElementById('tabellaFasciaWrap');
    if (!wrap) {
        return;
    }

    const area = wrap.closest('.tabella-scroll-area');
    const leftEdge = area.querySelector('.scroll-edge-left');
    const rightEdge = area.querySelector('.scroll-edge-right');

    if (!leftEdge || !rightEdge) {
        return;
    }

    let animationId = null;
    let direction = 0;
    const speed = 10;

    function maxScrollLeft() {
        return wrap.scrollWidth - wrap.clientWidth;
    }

    function updateEdges() {
        const max = maxScrollLeft();
        const current = wrap.scrollLeft;

        if (max <= 0) {
            leftEdge.classList.add('is-hidden');
            rightEdge.classList.add('is-hidden');
            stopAutoScroll();
            return;
        }

        leftEdge.classList.toggle('is-hidden', current <= 1);
        rightEdge.classList.toggle('is-hidden', current >= max - 1);
    }

    function stepScroll() {
        if (direction === 0) {
            animationId = null;
            return;
        }
        wrap.scrollLeft += direction * speed;
        updateEdges();
        animationId = requestAnimationFrame(stepScroll);
    }

    function startAutoScroll(newDirection, edgeElement) {
        direction = newDirection;
        leftEdge.classList.remove('is-active');
        rightEdge.classList.remove('is-active');
        if (edgeElement) {
            edgeElement.classList.add('is-active');
        }
        if (animationId === null) {
            animationId = requestAnimationFrame(stepScroll);
        }
    }

    function stopAutoScroll() {
        direction = 0;
        leftEdge.classList.remove('is-active');
        rightEdge.classList.remove('is-active');
        if (animationId !== null) {
            cancelAnimationFrame(animationId);
            animationId = null;
        }
    }

    leftEdge.addEventListener('mouseenter', function () {
        startAutoScroll(-1, leftEdge);
    });
    rightEdge.addEventListener('mouseenter', function () {
        startAutoScroll(1, rightEdge);
    });
    leftEdge.addEventListener('mouseleave', stopAutoScroll);
    rightEdge.addEventListener('mouseleave', stopAutoScroll);
    wrap.addEventListener('mouseleave', stopAutoScroll);

    wrap.addEventListener('scroll', updateEdges);
    window.addEventListener('resize', updateEdges);

    updateEdges();
});
</script>

</body>
</html>