<?php

// Include la connessione al database
require_once __DIR__ . '/../config/database.php';

// Imposta il percorso base e il titolo della pagina
$basePath = '../';
$titoloPagina = 'Palestra – Elimina Cliente';

// Recupera il codice del cliente dall'URL o dal form
$codice = trim($_GET['codice'] ?? $_POST['codice'] ?? '');

// Torna alla lista se il codice non è presente
if ($codice === '') {
    header('Location: clienti.php');
    exit;
}

// Inizializza le variabili della pagina
$cliente = null;
$numAbbonamenti = 0;
$numPrenotazioni = 0;
$errore = '';

try {
    // Recupera i dati del cliente
    $stmt = $pdo->prepare("SELECT * FROM Cliente WHERE codice = ?");
    $stmt->execute([$codice]);
    $cliente = $stmt->fetch(PDO::FETCH_ASSOC);

    // Torna alla lista se il cliente non esiste
    if (!$cliente) {
        header('Location: clienti.php');
        exit;
    }

    // Conta gli abbonamenti collegati al cliente
    $stmtAbb = $pdo->prepare("SELECT COUNT(*) FROM Abbonamento WHERE cliente = ?");
    $stmtAbb->execute([$codice]);
    $numAbbonamenti = (int) $stmtAbb->fetchColumn();

    // Conta le prenotazioni collegate al cliente
    $stmtPre = $pdo->prepare("SELECT COUNT(*) FROM Prenotazione WHERE cliente = ?");
    $stmtPre->execute([$codice]);
    $numPrenotazioni = (int) $stmtPre->fetchColumn();
} catch (Exception $e) {
    // Memorizza un messaggio se il caricamento fallisce
    $errore = "Errore nel caricamento dei dati del cliente.";
}

// Elimina anche i record SubAbbonamento degli abbonamenti di questo cliente,
// anche se collegati a prenotazioni di altri clienti
$stmtDelSubAbb = $pdo->prepare(
    'DELETE sa FROM SubAbbonamento sa
     JOIN Abbonamento a ON a.nAbb = sa.abbonamento
     WHERE a.cliente = ?'
);
$stmtDelSubAbb->execute([$codice]);

// Elimina i record SubAbbonamento collegati alle prenotazioni del cliente
$stmtDelSub = $pdo->prepare(
    'DELETE sa FROM SubAbbonamento sa
     JOIN Prenotazione p ON p.nProg = sa.prenotazione
     WHERE p.cliente = ?'
);
$stmtDelSub->execute([$codice]);

// Esegue l'eliminazione dopo la conferma del form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $errore === '') {
    try {
        // Avvia una transazione per rendere atomica l'eliminazione
        $pdo->beginTransaction();

        // Elimina i record SubAbbonamento collegati alle prenotazioni del cliente
        $stmtDelSub = $pdo->prepare(
            "DELETE sa
             FROM SubAbbonamento sa
             JOIN Prenotazione p ON p.nProg = sa.prenotazione
             WHERE p.cliente = ?"
        );
        $stmtDelSub->execute([$codice]);

        // Elimina le prenotazioni del cliente
        $stmtDelPre = $pdo->prepare("DELETE FROM Prenotazione WHERE cliente = ?");
        $stmtDelPre->execute([$codice]);

        // Elimina gli abbonamenti del cliente
        $stmtDelAbb = $pdo->prepare("DELETE FROM Abbonamento WHERE cliente = ?");
        $stmtDelAbb->execute([$codice]);

        // Elimina il cliente
        $stmtDelCli = $pdo->prepare("DELETE FROM Cliente WHERE codice = ?");
        $stmtDelCli->execute([$codice]);

        // Conferma tutte le eliminazioni
        $pdo->commit();

        // Torna alla lista con messaggio di conferma
        header('Location: clienti.php?eliminato=1');
        exit;
    } catch (Exception $e) {
        // Annulla tutte le modifiche se avviene un errore
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        $errore = "Non è stato possibile eliminare il cliente. Riprova più tardi.";
    }
}

// Include l'intestazione comune
require_once __DIR__ . '/../includes/header.php';
?>

<main class="corpo">

  <!-- Colonna laterale con il collegamento alla lista clienti -->
  <aside class="area-laterale">
    <section class="pannello-laterale">
      <a class="breadcrumb" href="clienti.php">&larr; Torna alla lista clienti</a>
    </section>
  </aside>

  <!-- Area centrale per confermare l'eliminazione -->
  <section class="area-contenuto">

    <h2>Elimina Cliente</h2>

    <!-- Mostra eventuali errori -->
    <?php if ($errore !== ''): ?>
      <p class="msg-errore"><?= htmlspecialchars($errore) ?></p>
    <?php endif; ?>

    <?php if ($cliente): ?>

      <!-- Scheda con i dati del cliente da eliminare -->
      <div class="scheda-elimina">
        <div class="scheda-campo">
          <label>Codice</label>
          <span><?= htmlspecialchars((string) $cliente['codice']) ?></span>
        </div>
        <div class="scheda-campo">
          <label>Nome e cognome</label>
          <span><?= htmlspecialchars($cliente['nome'] . ' ' . $cliente['cognome']) ?></span>
        </div>
        <div class="scheda-campo">
          <label>Codice Fiscale</label>
          <span><?= htmlspecialchars($cliente['cf']) ?></span>
        </div>
        <div class="scheda-campo">
          <label>Abbonamenti collegati</label>
          <span><?= $numAbbonamenti ?></span>
        </div>
        <div class="scheda-campo">
          <label>Prenotazioni collegate</label>
          <span><?= $numPrenotazioni ?></span>
        </div>
      </div>

      <!-- Avvisa sulle conseguenze dell'eliminazione -->
      <p class="msg-avviso">
        Stai per eliminare definitivamente questo cliente.
        <?php if ($numAbbonamenti > 0 || $numPrenotazioni > 0): ?>
          Verranno eliminati anche
          <?= $numAbbonamenti ?> abbonamento/i e
          <?= $numPrenotazioni ?> prenotazione/i collegati a questo cliente.
        <?php endif; ?>
        L'operazione non è reversibile.
      </p>

      <!-- Form di conferma eliminazione -->
      <form method="post" action="cliente_elimina.php">
        <input type="hidden" name="codice" value="<?= htmlspecialchars($codice) ?>">

        <div class="azioni-elimina">
          <button type="submit" class="btn-pericolo">Confermo, elimina il cliente</button>
          <a class="btn-secondario" href="clienti.php">Annulla</a>
        </div>
      </form>

    <?php endif; ?>

  </section>

  <!-- Include il menu comune -->
  <?php require_once __DIR__ . '/../includes/nav.php'; ?>

</main>

<!-- Include il footer comune -->
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

</body>
</html>