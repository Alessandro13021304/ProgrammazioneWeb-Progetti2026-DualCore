<?php

// Connessione al database
require_once __DIR__ . '/../config/database.php';

// Percorso base e titolo pagina
$basePath = '../';
$titoloPagina = 'DualCore Palestra - Abbonamenti';

// Formatta una data testuale GG/MM/AAAA
function formattaDataIt(?string $data): string
{
    if ($data === null || trim($data) === '') {
        return '';
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Filtri di ricerca ricevuti dal form
$nAbb = trim($_GET['nAbb'] ?? '');
$nome = trim($_GET['nome'] ?? '');
$cognome = trim($_GET['cognome'] ?? '');
$stato = trim($_GET['stato'] ?? '');

// Impostazioni paginazione
$recordPerPagina = 20;
$pagina = max(1, (int) ($_GET['pagina'] ?? 1));
$offset = ($pagina - 1) * $recordPerPagina;

// Variabili della pagina
$abbonamenti = [];
$errore = '';
$totaleAbbonamenti = 0;
$totalePagine = 1;

try {
    // Costruisce le condizioni di ricerca in modo dinamico
    $condizioni = [];
    $parametri = [];

    if ($nAbb !== '') {
        $condizioni[] = 'a.nAbb = :nAbb';
        $parametri[':nAbb'] = $nAbb;
    }

    if ($nome !== '') {
        $condizioni[] = 'c.nome LIKE :nome';
        $parametri[':nome'] = '%' . $nome . '%';
    }

    if ($cognome !== '') {
        $condizioni[] = 'c.cognome LIKE :cognome';
        $parametri[':cognome'] = '%' . $cognome . '%';
    }

    // Calcola lo stato dell'abbonamento a partire dalle date testuali
    $espressioneStato =
        "CASE
            WHEN CURDATE() < STR_TO_DATE(a.inizio, '%d/%m/%Y') THEN 'Futuro'
            WHEN CURDATE() BETWEEN STR_TO_DATE(a.inizio, '%d/%m/%Y')
                AND STR_TO_DATE(a.fine, '%d/%m/%Y') THEN 'Attivo'
            ELSE 'Scaduto'
        END";

    if ($stato !== '') {
        $condizioni[] = $espressioneStato . ' = :stato';
        $parametri[':stato'] = $stato;
    }

    $whereSql = '';
    if (!empty($condizioni)) {
        $whereSql = 'WHERE ' . implode(' AND ', $condizioni);
    }

    // Conta il totale degli abbonamenti trovati
    $sqlConteggio = "
        SELECT COUNT(*)
        FROM Abbonamento a
        INNER JOIN Cliente c ON c.codice = a.cliente
        $whereSql
    ";

    $stmtConteggio = $pdo->prepare($sqlConteggio);
    $stmtConteggio->execute($parametri);
    $totaleAbbonamenti = (int) $stmtConteggio->fetchColumn();

    $totalePagine = max(1, (int) ceil($totaleAbbonamenti / $recordPerPagina));

    if ($pagina > $totalePagine) {
        $pagina = $totalePagine;
        $offset = ($pagina - 1) * $recordPerPagina;
    }

    // Recupera gli abbonamenti della pagina corrente
    // LEFT JOIN su SubAbbonamento per contare le prenotazioni collegate
    $sql = "
        SELECT
            a.nAbb,
            a.cliente,
            a.inizio,
            a.fine,
            a.prezzo,
            c.nome,
            c.cognome,
            $espressioneStato AS stato,
            COUNT(sa.prenotazione) AS numero_prenotazioni
        FROM Abbonamento a
        INNER JOIN Cliente c ON c.codice = a.cliente
        LEFT JOIN SubAbbonamento sa ON sa.abbonamento = a.nAbb
        $whereSql
        GROUP BY
            a.nAbb, a.cliente, a.inizio, a.fine, a.prezzo,
            c.nome, c.cognome
        ORDER BY STR_TO_DATE(a.fine, '%d/%m/%Y') DESC
        LIMIT :limite OFFSET :offset
    ";

    $stmt = $pdo->prepare($sql);

    foreach ($parametri as $chiave => $valore) {
        $stmt->bindValue($chiave, $valore);
    }

    $stmt->bindValue(':limite', $recordPerPagina, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();

    $abbonamenti = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $errore = 'Non e stato possibile recuperare gli abbonamenti. Riprova piu tardi.';
}

// Crea il link a una pagina della paginazione, mantenendo i filtri
function creaLinkPagina(int $pagina, array $filtri): string
{
    $filtri['pagina'] = $pagina;
    return 'abbonamenti.php?' . http_build_query($filtri);
}

$filtriCorrenti = [
    'nAbb' => $nAbb,
    'nome' => $nome,
    'cognome' => $cognome,
    'stato' => $stato
];

// Include header e CSS
require_once __DIR__ . '/../includes/header.php';

?>

<main class="corpo">

    <!-- Colonna sinistra: filtri di ricerca -->
    <aside class="area-laterale">

        <section class="filtro-ricerca">
            <form method="get" action="abbonamenti.php">

                <input type="hidden" name="pagina" value="1">

                <label for="nAbb">Numero abbonamento</label>
                <input type="text" id="nAbb" name="nAbb" value="<?= htmlspecialchars($nAbb, ENT_QUOTES, 'UTF-8') ?>">

                <label for="nome">Nome cliente</label>
                <input type="text" id="nome" name="nome" value="<?= htmlspecialchars($nome, ENT_QUOTES, 'UTF-8') ?>">

                <label for="cognome">Cognome cliente</label>
                <input type="text" id="cognome" name="cognome" value="<?= htmlspecialchars($cognome, ENT_QUOTES, 'UTF-8') ?>">

                <label for="stato">Stato</label>
                <select id="stato" name="stato">
                    <option value="">-- Tutti gli stati --</option>
                    <option value="Attivo" <?= $stato === 'Attivo' ? 'selected' : '' ?>>Attivo</option>
                    <option value="Scaduto" <?= $stato === 'Scaduto' ? 'selected' : '' ?>>Scaduto</option>
                    <option value="Futuro" <?= $stato === 'Futuro' ? 'selected' : '' ?>>Futuro</option>
                </select>

                <button type="submit" class="btn">Cerca</button>
                <a href="abbonamenti.php" class="btn-secondario">Azzera filtri</a>

            </form>
        </section>

    </aside>

    <!-- Contenuto centrale: risultati della ricerca -->
    <section class="area-contenuto">

        <h2>Ricerca Abbonamenti</h2>

        <?php if ($errore !== ''): ?>

            <p class="msg-errore">
                <?= htmlspecialchars($errore, ENT_QUOTES, 'UTF-8') ?>
            </p>

        <?php else: ?>

            <!-- Riepilogo dei risultati -->
            <div class="scheda">
                <p class="mb-0">
                    Visualizzati <?= count($abbonamenti) ?> abbonamenti su <?= $totaleAbbonamenti ?>.
                </p>
            </div>

            <?php if (empty($abbonamenti)): ?>

                <p class="msg-avviso">
                    Nessun abbonamento trovato per i criteri inseriti.
                </p>

            <?php else: ?>

                <!-- Area con scroll assistito ai bordi laterali -->
                <div class="tabella-scroll-area">

                    <div class="scroll-edge scroll-edge-left is-hidden" data-scroll-edge="left" aria-hidden="true" title="Sposta la tabella a sinistra"></div>

                    <div class="tabella-wrap" id="tabellaAbbonamentiWrap">

                        <table class="tabella">
                            <thead>
                                <tr>
                                    <th>N. Abb.</th>
                                    <th>Cliente</th>
                                    <th>Inizio</th>
                                    <th>Fine</th>
                                    <th>Prezzo</th>
                                    <th>Stato</th>
                                    <th>Prenotazioni</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php foreach ($abbonamenti as $a): ?>

                                    <tr>

                                        <td data-label="N. Abb.">
                                            <a href="abbonamento_dettaglio.php?nAbb=<?= urlencode($a['nAbb']) ?>">
                                                #<?= htmlspecialchars((string) $a['nAbb'], ENT_QUOTES, 'UTF-8') ?>
                                            </a>
                                        </td>

                                        <td data-label="Cliente">
                                            <a
                                                class="link-cliente"
                                                href="cliente_dettaglio.php?codice=<?= urlencode($a['cliente']) ?>"
                                            >
                                                <?= htmlspecialchars($a['nome'] . ' ' . $a['cognome'], ENT_QUOTES, 'UTF-8') ?>
                                            </a>
                                        </td>

                                        <td data-label="Inizio">
                                            <?= formattaDataIt($a['inizio']) ?>
                                        </td>

                                        <td data-label="Fine">
                                            <?= formattaDataIt($a['fine']) ?>
                                        </td>

                                        <td data-label="Prezzo">
                                            <?= number_format((float) $a['prezzo'], 2, ',', '.') ?> &euro;
                                        </td>

                                        <td data-label="Stato">
                                            <?php if ($a['stato'] === 'Attivo'): ?>
                                                <span class="badge badge-attivo">Attivo</span>
                                            <?php elseif ($a['stato'] === 'Futuro'): ?>
                                                <span class="badge badge-futuro">Futuro</span>
                                            <?php else: ?>
                                                <span class="badge badge-scaduto">Scaduto</span>
                                            <?php endif; ?>
                                        </td>

                                        <td data-label="Prenotazioni">
                                            <?php if ((int) $a['numero_prenotazioni'] > 0): ?>
                                                <a href="prenotazioni.php?abbonamento=<?= urlencode($a['nAbb']) ?>">
                                                    <?= (int) $a['numero_prenotazioni'] ?>
                                                </a>
                                            <?php else: ?>
                                                <span class="nessuno">0</span>
                                            <?php endif; ?>
                                        </td>

                                    </tr>

                                <?php endforeach; ?>
                            </tbody>
                        </table>

                    </div>

                    <div class="scroll-edge scroll-edge-right" data-scroll-edge="right" aria-hidden="true" title="Sposta la tabella a destra"></div>

                </div>

                <!-- Paginazione -->
                <?php if ($totalePagine > 1): ?>

                    <nav class="pagination-wrap" aria-label="Paginazione abbonamenti">

                        <div class="pagination-info">
                            Pagina <?= $pagina ?> di <?= $totalePagine ?>
                        </div>

                        <div class="pagination-nav">

                            <?php if ($pagina > 1): ?>
                                <a
                                    class="pagination-link pagination-arrow"
                                    href="<?= htmlspecialchars(creaLinkPagina($pagina - 1, $filtriCorrenti), ENT_QUOTES, 'UTF-8') ?>"
                                >
                                    &larr; Precedente
                                </a>
                            <?php else: ?>
                                <span class="pagination-disabled pagination-arrow">&larr; Precedente</span>
                            <?php endif; ?>

                            <?php
                            $inizio = max(1, $pagina - 2);
                            $fine = min($totalePagine, $pagina + 2);
                            ?>

                            <?php for ($i = $inizio; $i <= $fine; $i++): ?>
                                <?php if ($i === $pagina): ?>
                                    <span class="pagination-current"><?= $i ?></span>
                                <?php else: ?>
                                    <a
                                        class="pagination-link"
                                        href="<?= htmlspecialchars(creaLinkPagina($i, $filtriCorrenti), ENT_QUOTES, 'UTF-8') ?>"
                                    >
                                        <?= $i ?>
                                    </a>
                                <?php endif; ?>
                            <?php endfor; ?>

                            <?php if ($pagina < $totalePagine): ?>
                                <a
                                    class="pagination-link pagination-arrow"
                                    href="<?= htmlspecialchars(creaLinkPagina($pagina + 1, $filtriCorrenti), ENT_QUOTES, 'UTF-8') ?>"
                                >
                                    Successiva &rarr;
                                </a>
                            <?php else: ?>
                                <span class="pagination-disabled pagination-arrow">Successiva &rarr;</span>
                            <?php endif; ?>

                        </div>

                    </nav>

                <?php endif; ?>

            <?php endif; ?>

        <?php endif; ?>

    </section>

    <!-- Menu laterale destro -->
    <?php require_once __DIR__ . '/../includes/nav.php'; ?>

</main>

<!-- Footer -->
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<!-- Gestisce lo scroll automatico ai bordi della tabella -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    const wrap = document.getElementById('tabellaAbbonamentiWrap');
    if (!wrap) {
        return;
    }

    const area = wrap.closest('.tabella-scroll-area');
    const leftEdge = area.querySelector('.scroll-edge-left');
    const rightEdge = area.querySelector('.scroll-edge-right');

    if (!leftEdge || !rightEdge) {
        return;
    }

    let animationId = null;
    let direction = 0;
    const speed = 10;

    function maxScrollLeft() {
        return wrap.scrollWidth - wrap.clientWidth;
    }

    function updateEdges() {
        const max = maxScrollLeft();
        const current = wrap.scrollLeft;

        if (max <= 0) {
            leftEdge.classList.add('is-hidden');
            rightEdge.classList.add('is-hidden');
            stopAutoScroll();
            return;
        }

        leftEdge.classList.toggle('is-hidden', current <= 1);
        rightEdge.classList.toggle('is-hidden', current >= max - 1);
    }

    function stepScroll() {
        if (direction === 0) {
            animationId = null;
            return;
        }
        wrap.scrollLeft += direction * speed;
        updateEdges();
        animationId = requestAnimationFrame(stepScroll);
    }

    function startAutoScroll(newDirection, edgeElement) {
        direction = newDirection;
        leftEdge.classList.remove('is-active');
        rightEdge.classList.remove('is-active');
        if (edgeElement) {
            edgeElement.classList.add('is-active');
        }
        if (animationId === null) {
            animationId = requestAnimationFrame(stepScroll);
        }
    }

    function stopAutoScroll() {
        direction = 0;
        leftEdge.classList.remove('is-active');
        rightEdge.classList.remove('is-active');
        if (animationId !== null) {
            cancelAnimationFrame(animationId);
            animationId = null;
        }
    }

    leftEdge.addEventListener('mouseenter', function () {
        startAutoScroll(-1, leftEdge);
    });
    rightEdge.addEventListener('mouseenter', function () {
        startAutoScroll(1, rightEdge);
    });
    leftEdge.addEventListener('mouseleave', stopAutoScroll);
    rightEdge.addEventListener('mouseleave', stopAutoScroll);
    wrap.addEventListener('mouseleave', stopAutoScroll);

    wrap.addEventListener('scroll', updateEdges);
    window.addEventListener('resize', updateEdges);

    updateEdges();
});
</script>

</body>
</html>