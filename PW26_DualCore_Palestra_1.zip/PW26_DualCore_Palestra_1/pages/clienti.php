<?php

// Connessione al database
require_once __DIR__ . '/../config/database.php';

// Percorso base e titolo pagina
$basePath = '../';
$titoloPagina = 'DualCore Palestra - Ricerca Clienti';

// Formatta una data dal database al formato italiano
function formattaDataVisualizzata($data)
{
    if ($data === null || trim($data) === '') {
        return '';
    }

    $data = trim($data);
    $dateTime = DateTime::createFromFormat('!Y-m-d', $data);

    if ($dateTime !== false && $dateTime->format('Y-m-d') === $data) {
        return $dateTime->format('d/m/Y');
    }

    return htmlspecialchars($data);
}

// Filtri di ricerca ricevuti dal form
$nome = trim($_GET['nome'] ?? '');
$cognome = trim($_GET['cognome'] ?? '');
$cf = trim($_GET['cf'] ?? '');
$tel = trim($_GET['tel'] ?? '');

// Impostazioni paginazione
$recordPerPagina = 20;
$pagina = max(1, (int) ($_GET['pagina'] ?? 1));
$offset = ($pagina - 1) * $recordPerPagina;

$messaggio = '';
$errore = '';
$clienti = [];
$totaleClienti = 0;
$totalePagine = 1;

// Imposta il messaggio dopo inserimento, modifica o eliminazione
if (isset($_GET['creato'])) {
    $messaggio = 'Cliente creato correttamente.';
} elseif (isset($_GET['aggiornato'])) {
    $messaggio = 'Cliente aggiornato correttamente.';
} elseif (isset($_GET['eliminato'])) {
    $messaggio = 'Cliente eliminato correttamente.';
}

try {
    // Costruisce le condizioni di ricerca in modo dinamico
    $condizioni = [];
    $parametri = [];

    if ($nome !== '') {
        $condizioni[] = 'nome LIKE :nome';
        $parametri[':nome'] = '%' . $nome . '%';
    }

    if ($cognome !== '') {
        $condizioni[] = 'cognome LIKE :cognome';
        $parametri[':cognome'] = '%' . $cognome . '%';
    }

    if ($cf !== '') {
        $condizioni[] = 'cf LIKE :cf';
        $parametri[':cf'] = '%' . $cf . '%';
    }

    if ($tel !== '') {
        $condizioni[] = 'tel LIKE :tel';
        $parametri[':tel'] = '%' . $tel . '%';
    }

    $whereSql = '';
    if (!empty($condizioni)) {
        $whereSql = 'WHERE ' . implode(' AND ', $condizioni);
    }

    // Conta i clienti rispettando i filtri
    $sqlCount = "SELECT COUNT(*) FROM Cliente $whereSql";
    $stmtTotale = $pdo->prepare($sqlCount);
    $stmtTotale->execute($parametri);

    $totaleClienti = (int) $stmtTotale->fetchColumn();
    $totalePagine = max(1, (int) ceil($totaleClienti / $recordPerPagina));

    // Evita di richiedere una pagina oltre l'ultima disponibile
    if ($pagina > $totalePagine) {
        $pagina = $totalePagine;
        $offset = ($pagina - 1) * $recordPerPagina;
    }

    // Recupera i clienti della pagina corrente
    $sql = "
        SELECT codice, nome, cognome, cf, dataNas, indirizzo, tel, email
        FROM Cliente
        $whereSql
        ORDER BY cognome ASC, nome ASC, codice ASC
        LIMIT :limite OFFSET :offset
    ";

    $stmt = $pdo->prepare($sql);

    foreach ($parametri as $chiave => $valore) {
        $stmt->bindValue($chiave, $valore, PDO::PARAM_STR);
    }

    $stmt->bindValue(':limite', $recordPerPagina, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();

    $clienti = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Imposta i valori sicuri se il recupero dei clienti fallisce
    $clienti = [];
    $totaleClienti = 0;
    $totalePagine = 1;
    $errore = "Non e stato possibile recuperare l'elenco dei clienti.";
}

// Crea il collegamento per una pagina della paginazione, mantenendo i filtri
function buildPaginaLink($pagina, $nome, $cognome, $cf, $tel)
{
    $parametri = ['pagina' => $pagina];

    if ($nome !== '') {
        $parametri['nome'] = $nome;
    }

    if ($cognome !== '') {
        $parametri['cognome'] = $cognome;
    }

    if ($cf !== '') {
        $parametri['cf'] = $cf;
    }

    if ($tel !== '') {
        $parametri['tel'] = $tel;
    }

    return 'clienti.php?' . http_build_query($parametri);
}

// Verifica se e' stato applicato almeno un filtro
$filtriAttivi = ($nome !== '' || $cognome !== '' || $cf !== '' || $tel !== '');

// Include header e CSS
require_once __DIR__ . '/../includes/header.php';

?>

<main class="corpo">

    <!-- Colonna sinistra: nuovo cliente in cima, poi i filtri -->
    <aside class="area-laterale">

        <section class="azione-laterale">
            <div class="cliente-toolbar">
                <a class="btn cliente-nuovo-btn" href="cliente_form.php">
                    + Nuovo cliente
                </a>
            </div>
        </section>

        <section class="filtro-ricerca">
            <form method="get" action="clienti.php">

                <input type="hidden" name="pagina" value="1">

                <label for="nome">
                    Nome
                    <input
                        type="text"
                        id="nome"
                        name="nome"
                        value="<?= htmlspecialchars($nome) ?>"
                    >
                </label>

                <label for="cognome">
                    Cognome
                    <input
                        type="text"
                        id="cognome"
                        name="cognome"
                        value="<?= htmlspecialchars($cognome) ?>"
                    >
                </label>

                <label for="cf">
                    Codice Fiscale
                    <input
                        type="text"
                        id="cf"
                        name="cf"
                        value="<?= htmlspecialchars($cf) ?>"
                    >
                </label>

                <label for="tel">
                    Telefono
                    <input
                        type="text"
                        id="tel"
                        name="tel"
                        value="<?= htmlspecialchars($tel) ?>"
                    >
                </label>

                <button type="submit" class="btn">
                    Cerca
                </button>

                <a href="clienti.php" class="btn-secondario">
                    Azzera filtri
                </a>

            </form>
        </section>

    </aside>

    <!-- Area centrale con risultati della ricerca -->
    <section class="area-contenuto">

        <h2>Ricerca Clienti</h2>

        <!-- Mostra il messaggio dopo un'operazione -->
        <?php if ($messaggio !== ''): ?>
            <p class="msg-successo"><?= htmlspecialchars($messaggio) ?></p>
        <?php endif; ?>

        <!-- Mostra un errore oppure i risultati -->
        <?php if ($errore !== ''): ?>
            <p class="msg-errore"><?= htmlspecialchars($errore) ?></p>
        <?php else: ?>

            <!-- Riepilogo dei risultati -->
            <div class="scheda">
                <p class="mb-0">
                    <?php if ($filtriAttivi): ?>
                        Trovati <?= $totaleClienti ?> clienti per i criteri inseriti.
                    <?php else: ?>
                        Visualizzati <?= count($clienti) ?> clienti su <?= $totaleClienti ?>.
                    <?php endif; ?>
                </p>
            </div>

            <!-- Mostra un avviso se non ci sono clienti -->
            <?php if (empty($clienti)): ?>
                <p class="msg-errore">
                    Nessun cliente trovato<?= $filtriAttivi ? ' per i criteri inseriti' : '' ?>.
                </p>
            <?php else: ?>

                <!-- Area con scroll assistito ai bordi laterali -->
                <div class="tabella-scroll-area">

                    <div
                        class="scroll-edge scroll-edge-left is-hidden"
                        data-scroll-edge="left"
                        aria-hidden="true"
                        title="Sposta la tabella a sinistra"
                    ></div>

                    <div class="tabella-wrap" id="tabellaClientiWrap">
                        <table class="tabella">
                            <colgroup>
                                <col class="col-cognome">
                                <col class="col-nome">
                                <col class="col-cf">
                                <col class="col-data">
                                <col class="col-telefono">
                                <col class="col-email">
                                <col class="col-indirizzo">
                                <col class="col-azioni">
                            </colgroup>

                            <thead>
                                <tr>
                                    <th>Cognome</th>
                                    <th>Nome</th>
                                    <th>Codice Fiscale</th>
                                    <th>Data di nascita</th>
                                    <th>Telefono</th>
                                    <th>Email</th>
                                    <th>Indirizzo</th>
                                    <th>Azioni</th>
                                </tr>
                            </thead>

                            <tbody>

                                <?php foreach ($clienti as $cliente): ?>

                                    <?php
                                    // Link al dettaglio del cliente
                                    $urlDettaglio = 'cliente_dettaglio.php?codice=' . urlencode($cliente['codice']);
                                    ?>

                                    <tr>
                                        <td data-label="Cognome">
                                            <a
                                                class="link-cliente"
                                                href="<?= htmlspecialchars($urlDettaglio) ?>"
                                                aria-label="Apri il dettaglio di <?= htmlspecialchars($cliente['nome'] . ' ' . $cliente['cognome']) ?>"
                                            >
                                                <?= htmlspecialchars($cliente['cognome']) ?>
                                            </a>
                                        </td>

                                        <td data-label="Nome">
                                            <a
                                                class="link-cliente"
                                                href="<?= htmlspecialchars($urlDettaglio) ?>"
                                                aria-label="Apri il dettaglio di <?= htmlspecialchars($cliente['nome'] . ' ' . $cliente['cognome']) ?>"
                                            >
                                                <?= htmlspecialchars($cliente['nome']) ?>
                                            </a>
                                        </td>

                                        <td data-label="Codice Fiscale"><?= htmlspecialchars($cliente['cf']) ?></td>
                                        <td data-label="Data di nascita"><?= formattaDataVisualizzata($cliente['dataNas']) ?></td>
                                        <td data-label="Telefono"><?= htmlspecialchars($cliente['tel']) ?></td>
                                        <td data-label="Email">
                                            <a href="mailto:<?= htmlspecialchars($cliente['email']) ?>">
                                                <?= htmlspecialchars($cliente['email']) ?>
                                            </a>
                                        </td>
                                        <td data-label="Indirizzo"><?= htmlspecialchars($cliente['indirizzo']) ?></td>

                                        <td data-label="Azioni">
                                            <div class="azioni-tabella">
                                                <a
                                                    href="cliente_form.php?codice=<?= urlencode($cliente['codice']) ?>"
                                                    class="btn-secondario"
                                                >
                                                    Modifica
                                                </a>

                                                <a
                                                    href="cliente_elimina.php?codice=<?= urlencode($cliente['codice']) ?>"
                                                    class="btn-secondario"
                                                    onclick="return confirm('Vuoi eliminare questo cliente?');"
                                                >
                                                    Elimina
                                                </a>
                                            </div>
                                        </td>
                                    </tr>

                                <?php endforeach; ?>

                            </tbody>
                        </table>
                    </div>

                    <div
                        class="scroll-edge scroll-edge-right"
                        data-scroll-edge="right"
                        aria-hidden="true"
                        title="Sposta la tabella a destra"
                    ></div>

                </div>

                <!-- Paginazione -->
                <?php if ($totalePagine > 1): ?>

                    <nav class="pagination-wrap" aria-label="Paginazione clienti">

                        <div class="pagination-info">
                            Pagina <?= $pagina ?> di <?= $totalePagine ?>
                        </div>

                        <div class="pagination-nav">

                            <?php if ($pagina > 1): ?>
                                <a
                                    class="pagination-link pagination-arrow"
                                    href="<?= htmlspecialchars(buildPaginaLink($pagina - 1, $nome, $cognome, $cf, $tel)) ?>"
                                    aria-label="Vai alla pagina precedente"
                                >
                                    &larr; Precedente
                                </a>
                            <?php else: ?>
                                <span class="pagination-disabled pagination-arrow" aria-disabled="true">
                                    &larr; Precedente
                                </span>
                            <?php endif; ?>

                            <?php
                            $inizio = max(1, $pagina - 2);
                            $fine = min($totalePagine, $pagina + 2);
                            ?>

                            <?php for ($i = $inizio; $i <= $fine; $i++): ?>
                                <?php if ($i === $pagina): ?>
                                    <span class="pagination-current" aria-current="page">
                                        <?= $i ?>
                                    </span>
                                <?php else: ?>
                                    <a
                                        class="pagination-link"
                                        href="<?= htmlspecialchars(buildPaginaLink($i, $nome, $cognome, $cf, $tel)) ?>"
                                        aria-label="Vai alla pagina <?= $i ?>"
                                    >
                                        <?= $i ?>
                                    </a>
                                <?php endif; ?>
                            <?php endfor; ?>

                            <?php if ($pagina < $totalePagine): ?>
                                <a
                                    class="pagination-link pagination-arrow"
                                    href="<?= htmlspecialchars(buildPaginaLink($pagina + 1, $nome, $cognome, $cf, $tel)) ?>"
                                    aria-label="Vai alla pagina successiva"
                                >
                                    Successiva &rarr;
                                </a>
                            <?php else: ?>
                                <span class="pagination-disabled pagination-arrow" aria-disabled="true">
                                    Successiva &rarr;
                                </span>
                            <?php endif; ?>

                        </div>

                    </nav>

                <?php endif; ?>

            <?php endif; ?>
        <?php endif; ?>

    </section>

    <!-- Menu laterale destro -->
    <?php require_once __DIR__ . '/../includes/nav.php'; ?>

</main>

<!-- Footer -->
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<!-- Gestisce lo scroll automatico della tabella ai bordi laterali -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    const wrap = document.getElementById('tabellaClientiWrap');
    const leftEdge = document.querySelector('[data-scroll-edge="left"]');
    const rightEdge = document.querySelector('[data-scroll-edge="right"]');

    if (!wrap || !leftEdge || !rightEdge) {
        return;
    }

    let animationId = null;
    let direction = 0;
    const speed = 10;

    // Calcola il valore massimo dello scroll orizzontale
    function maxScrollLeft() {
        return wrap.scrollWidth - wrap.clientWidth;
    }

    // Mostra o nasconde gli indicatori laterali
    function updateEdges() {
        const max = maxScrollLeft();
        const current = wrap.scrollLeft;

        if (max <= 0) {
            leftEdge.classList.add('is-hidden');
            rightEdge.classList.add('is-hidden');
            stopAutoScroll();
            return;
        }

        leftEdge.classList.toggle('is-hidden', current <= 1);
        rightEdge.classList.toggle('is-hidden', current >= max - 1);
    }

    // Esegue un passo dello scroll automatico
    function stepScroll() {
        if (direction === 0) {
            animationId = null;
            return;
        }

        wrap.scrollLeft += direction * speed;
        updateEdges();
        animationId = requestAnimationFrame(stepScroll);
    }

    // Avvia lo scroll verso sinistra o destra
    function startAutoScroll(newDirection, edgeElement) {
        direction = newDirection;

        leftEdge.classList.remove('is-active');
        rightEdge.classList.remove('is-active');

        if (edgeElement) {
            edgeElement.classList.add('is-active');
        }

        if (animationId === null) {
            animationId = requestAnimationFrame(stepScroll);
        }
    }

    // Arresta lo scroll automatico
    function stopAutoScroll() {
        direction = 0;
        leftEdge.classList.remove('is-active');
        rightEdge.classList.remove('is-active');

        if (animationId !== null) {
            cancelAnimationFrame(animationId);
            animationId = null;
        }
    }

    // Avvia lo scroll quando il mouse entra nelle bande laterali
    leftEdge.addEventListener('mouseenter', function () {
        startAutoScroll(-1, leftEdge);
    });

    rightEdge.addEventListener('mouseenter', function () {
        startAutoScroll(1, rightEdge);
    });

    // Arresta lo scroll quando il mouse esce dalla banda o dalla tabella
    leftEdge.addEventListener('mouseleave', stopAutoScroll);
    rightEdge.addEventListener('mouseleave', stopAutoScroll);
    wrap.addEventListener('mouseleave', stopAutoScroll);

    // Aggiorna gli indicatori durante lo scroll e al ridimensionamento
    wrap.addEventListener('scroll', updateEdges);
    window.addEventListener('resize', updateEdges);

    updateEdges();
});
</script>

</body>
</html>
