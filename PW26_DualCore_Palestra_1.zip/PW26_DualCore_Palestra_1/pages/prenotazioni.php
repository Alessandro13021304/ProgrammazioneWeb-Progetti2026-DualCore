<?php

// Connessione al database
require_once __DIR__ . '/../config/database.php';

// Percorso base e titolo pagina
$basePath = '../';
$titoloPagina = 'DualCore Palestra - Ricerca Prenotazioni';

// Formatta una data testuale GG/MM/AAAA
function formattaDataIt(?string $data): string
{
    if ($data === null || trim($data) === '') {
        return '';
    }
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}

// Mostra l'orario come HH:MM
function formattaOra(?string $ora): string
{
    if ($ora === null || trim($ora) === '') {
        return '';
    }
    return htmlspecialchars(substr(trim($ora), 0, 5), ENT_QUOTES, 'UTF-8');
}

// Converte una data in formato ISO, qualunque sia il formato di arrivo
function convertiDataIso(string $data): string
{
    $data = trim($data);

    if ($data === '') {
        return '';
    }

    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) {
        return $data;
    }

    $dt = DateTime::createFromFormat('d/m/Y', $data);

    if ($dt !== false) {
        return $dt->format('Y-m-d');
    }

    return $data;
}

// Filtri ricevuti dal form o da link esterni
$dataDa = convertiDataIso(trim($_GET['data_da'] ?? $_GET['datada'] ?? ''));
$dataA = convertiDataIso(trim($_GET['data_a'] ?? $_GET['dataa'] ?? ''));
$sala = trim($_GET['sala'] ?? '');
$cliente = trim($_GET['cliente'] ?? '');
$abbonamento = trim($_GET['abbonamento'] ?? '');
$tipo = trim($_GET['tipo'] ?? '');
$numero = trim($_GET['numero'] ?? '');

// Impostazioni paginazione
$recordPerPagina = 25;
$pagina = max(1, (int) ($_GET['pagina'] ?? 1));
$offset = ($pagina - 1) * $recordPerPagina;

// Carica le sale per il menu a tendina
$saleLista = [];

try {
    $stmtSale = $pdo->query('SELECT codice, nome FROM Sala ORDER BY nome');
    $saleLista = $stmtSale->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $saleLista = [];
}

// Variabili dei risultati
$prenotazioni = [];
$errore = '';
$numeroPrenotazioni = 0;
$numeroPagine = 1;

$dataDaValida = ($dataDa === '' || DateTime::createFromFormat('Y-m-d', $dataDa) !== false);
$dataAValida = ($dataA === '' || DateTime::createFromFormat('Y-m-d', $dataA) !== false);

if (!$dataDaValida || !$dataAValida) {
    $errore = 'Formato data non valido. Usa il selettore per scegliere le date.';
} elseif ($dataDa !== '' && $dataA !== '' && $dataDa > $dataA) {
    $errore = 'La data di inizio non puo essere successiva alla data di fine.';
} else {

    $condizioni = [];
    $parametri = [];

    if ($dataDa !== '') {
        $condizioni[] = "STR_TO_DATE(p.data, '%d/%m/%Y') >= :dataDa";
        $parametri[':dataDa'] = $dataDa;
    }

    if ($dataA !== '') {
        $condizioni[] = "STR_TO_DATE(p.data, '%d/%m/%Y') <= :dataA";
        $parametri[':dataA'] = $dataA;
    }

    if ($sala !== '') {
        $condizioni[] = 'p.sala = :sala';
        $parametri[':sala'] = $sala;
    }

    if ($cliente !== '') {
        $condizioni[] = 'p.cliente = :cliente';
        $parametri[':cliente'] = $cliente;
    }

    if ($numero !== '') {
        $condizioni[] = 'p.nProg = :numero';
        $parametri[':numero'] = $numero;
    }

    if ($abbonamento !== '') {
        $condizioni[] = 'sa.abbonamento = :abbonamento';
        $parametri[':abbonamento'] = $abbonamento;
    }

    if ($tipo === 'semplice') {
        $condizioni[] = 'sa.prenotazione IS NULL';
    } elseif ($tipo === 'sub') {
        $condizioni[] = 'sa.prenotazione IS NOT NULL';
    }

    $whereSql = '';
    if (!empty($condizioni)) {
        $whereSql = 'WHERE ' . implode(' AND ', $condizioni);
    }

    try {
        $sqlConteggio = "
            SELECT COUNT(*)
            FROM Prenotazione p
            LEFT JOIN SubAbbonamento sa ON sa.prenotazione = p.nProg
            $whereSql
        ";

        $stmtConteggio = $pdo->prepare($sqlConteggio);
        $stmtConteggio->execute($parametri);
        $numeroPrenotazioni = (int) $stmtConteggio->fetchColumn();

        $numeroPagine = max(1, (int) ceil($numeroPrenotazioni / $recordPerPagina));

        if ($pagina > $numeroPagine) {
            $pagina = $numeroPagine;
            $offset = ($pagina - 1) * $recordPerPagina;
        }

        $sql = "
            SELECT
                p.nProg,
                p.cliente,
                p.sala AS sala_codice,
                p.data,
                p.ora,
                p.posto,
                c.nome AS cliente_nome,
                c.cognome AS cliente_cognome,
                s.nome AS sala_nome,
                sa.abbonamento AS numero_abbonamento,
                CASE
                    WHEN sa.prenotazione IS NOT NULL THEN 'Sub Abbonamento'
                    ELSE 'Semplice'
                END AS tipo_prenotazione
            FROM Prenotazione p
            INNER JOIN Cliente c ON c.codice = p.cliente
            INNER JOIN Sala s ON s.codice = p.sala
            LEFT JOIN SubAbbonamento sa ON sa.prenotazione = p.nProg
            $whereSql
            ORDER BY STR_TO_DATE(p.data, '%d/%m/%Y') DESC, p.ora DESC, p.nProg DESC
            LIMIT :limite OFFSET :offset
        ";

        $stmt = $pdo->prepare($sql);

        foreach ($parametri as $chiave => $valore) {
            $stmt->bindValue($chiave, $valore);
        }

        $stmt->bindValue(':limite', $recordPerPagina, PDO::PARAM_INT);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->execute();

        $prenotazioni = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Exception $e) {
        $errore = 'Errore durante la ricerca. Riprova piu tardi.';
    }
}

function creaLinkPagina(int $pagina, array $filtri): string
{
    $filtri['pagina'] = $pagina;
    return 'prenotazioni.php?' . http_build_query($filtri);
}

$filtriCorrenti = [
    'data_da' => $dataDa,
    'data_a' => $dataA,
    'sala' => $sala,
    'cliente' => $cliente,
    'abbonamento' => $abbonamento,
    'tipo' => $tipo,
    'numero' => $numero
];

require_once __DIR__ . '/../includes/header.php';

?>

<main class="corpo">

    <!-- Colonna sinistra: filtri di ricerca -->
    <aside class="area-laterale">

        <section class="filtro-ricerca">
            <form method="get" action="prenotazioni.php">

                <input type="hidden" name="pagina" value="1">

                <label for="data_da">
                    Data (da)
                    <input
                        type="date"
                        id="data_da"
                        name="data_da"
                        value="<?= htmlspecialchars($dataDa, ENT_QUOTES, 'UTF-8') ?>"
                    >
                </label>

                <label for="data_a">
                    Data (a)
                    <input
                        type="date"
                        id="data_a"
                        name="data_a"
                        value="<?= htmlspecialchars($dataA, ENT_QUOTES, 'UTF-8') ?>"
                    >
                </label>

                <label for="sala">
                    Sala
                    <select id="sala" name="sala">
                        <option value="">-- Tutte le sale --</option>
                        <?php foreach ($saleLista as $s): ?>
                            <option
                                value="<?= htmlspecialchars((string) $s['codice'], ENT_QUOTES, 'UTF-8') ?>"
                                <?= $sala === (string) $s['codice'] ? 'selected' : '' ?>
                            >
                                <?= htmlspecialchars($s['nome'], ENT_QUOTES, 'UTF-8') ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </label>

                <label for="tipo">
                    Tipo
                    <select id="tipo" name="tipo">
                        <option value="">-- Tutti i tipi --</option>
                        <option value="semplice" <?= $tipo === 'semplice' ? 'selected' : '' ?>>Semplice</option>
                        <option value="sub" <?= $tipo === 'sub' ? 'selected' : '' ?>>Sub Abbonamento</option>
                    </select>
                </label>

                <button type="submit" class="btn">Cerca</button>
                <a href="prenotazioni.php" class="btn-secondario">Azzera filtri</a>

            </form>
        </section>

    </aside>

    <!-- Contenuto centrale -->
    <section class="area-contenuto">

        <h2>Ricerca Prenotazioni</h2>

        <?php if ($errore !== ''): ?>

            <p class="msg-errore">
                <?= htmlspecialchars($errore, ENT_QUOTES, 'UTF-8') ?>
            </p>

        <?php elseif (empty($prenotazioni)): ?>

            <p class="msg-avviso">
                Nessuna prenotazione trovata per i criteri inseriti.
            </p>

        <?php else: ?>

            <!-- Riepilogo dei risultati -->
            <div class="scheda">
                <p class="mb-0">
                    Visualizzate <?= count($prenotazioni) ?> prenotazioni su <?= $numeroPrenotazioni ?>.
                </p>
            </div>

            <!-- Area con scroll assistito ai bordi laterali -->
            <div class="tabella-scroll-area">

                <div class="scroll-edge scroll-edge-left is-hidden" data-scroll-edge="left" aria-hidden="true" title="Sposta la tabella a sinistra"></div>

                <div class="tabella-wrap" id="tabellaPrenotazioniWrap">

                    <table class="tabella tabella-prenotazioni">
                        <thead>
                            <tr>
                                <th>Data</th>
                                <th>Ora</th>
                                <th>Sala</th>
                                <th>Cliente</th>
                                <th>Posto</th>
                                <th>Tipo</th>
                                <th>Abbonamento</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php foreach ($prenotazioni as $p): ?>

                                <?php
                                $urlFascia = 'fasciaoraria.php?' . http_build_query([
                                    'sala' => $p['sala_codice'],
                                    'data' => $p['data'],
                                    'ora' => substr($p['ora'], 0, 5)
                                ]);

                                $urlPosto = 'posto.php?' . http_build_query([
                                    'sala' => $p['sala_codice'],
                                    'data' => $p['data'],
                                    'ora' => substr($p['ora'], 0, 5),
                                    'posto' => $p['posto']
                                ]);
                                ?>

                                <tr>

                                    <td data-label="Data">
                                        <?= formattaDataIt($p['data']) ?>
                                    </td>

                                    <td data-label="Ora">
                                        <a href="<?= htmlspecialchars($urlFascia, ENT_QUOTES, 'UTF-8') ?>">
                                            <?= formattaOra($p['ora']) ?>
                                        </a>
                                    </td>

                                    <td data-label="Sala">
                                        <a href="sala_dettaglio.php?codice=<?= urlencode($p['sala_codice']) ?>">
                                            <?= htmlspecialchars($p['sala_nome'], ENT_QUOTES, 'UTF-8') ?>
                                        </a>
                                    </td>

                                    <td data-label="Cliente">
                                        <a
                                            class="link-cliente"
                                            href="cliente_dettaglio.php?codice=<?= urlencode($p['cliente']) ?>"
                                        >
                                            <?= htmlspecialchars($p['cliente_nome'] . ' ' . $p['cliente_cognome'], ENT_QUOTES, 'UTF-8') ?>
                                        </a>
                                    </td>

                                    <td data-label="Posto">
                                        <a href="<?= htmlspecialchars($urlPosto, ENT_QUOTES, 'UTF-8') ?>">
                                            <?= htmlspecialchars((string) $p['posto'], ENT_QUOTES, 'UTF-8') ?>
                                        </a>
                                    </td>

                                    <td data-label="Tipo">
                                        <span class="tag-tipo <?= $p['tipo_prenotazione'] === 'Sub Abbonamento' ? 'tag-abbonamento' : 'tag-semplice' ?>">
                                            <?= htmlspecialchars($p['tipo_prenotazione'], ENT_QUOTES, 'UTF-8') ?>
                                        </span>
                                    </td>

                                    <td data-label="Abbonamento">
                                        <?php if ($p['numero_abbonamento'] !== null): ?>
                                            <a href="abbonamento_dettaglio.php?nAbb=<?= urlencode($p['numero_abbonamento']) ?>">
                                                #<?= htmlspecialchars((string) $p['numero_abbonamento'], ENT_QUOTES, 'UTF-8') ?>
                                            </a>
                                        <?php else: ?>
                                            <span class="nessuno">-</span>
                                        <?php endif; ?>
                                    </td>

                                </tr>

                            <?php endforeach; ?>

                        </tbody>
                    </table>

                </div>

                <div class="scroll-edge scroll-edge-right" data-scroll-edge="right" aria-hidden="true" title="Sposta la tabella a destra"></div>

            </div>

            <!-- Paginazione -->
            <?php if ($numeroPagine > 1): ?>

                <nav class="pagination-wrap" aria-label="Paginazione prenotazioni">

                    <div class="pagination-info">
                        Pagina <?= $pagina ?> di <?= $numeroPagine ?>
                    </div>

                    <div class="pagination-nav">

                        <?php if ($pagina > 1): ?>
                            <a
                                class="pagination-link pagination-arrow"
                                href="<?= htmlspecialchars(creaLinkPagina($pagina - 1, $filtriCorrenti), ENT_QUOTES, 'UTF-8') ?>"
                            >
                                &larr; Precedente
                            </a>
                        <?php else: ?>
                            <span class="pagination-disabled pagination-arrow">&larr; Precedente</span>
                        <?php endif; ?>

                        <?php
                        $inizio = max(1, $pagina - 2);
                        $fine = min($numeroPagine, $pagina + 2);
                        ?>

                        <?php for ($i = $inizio; $i <= $fine; $i++): ?>
                            <?php if ($i === $pagina): ?>
                                <span class="pagination-current"><?= $i ?></span>
                            <?php else: ?>
                                <a
                                    class="pagination-link"
                                    href="<?= htmlspecialchars(creaLinkPagina($i, $filtriCorrenti), ENT_QUOTES, 'UTF-8') ?>"
                                >
                                    <?= $i ?>
                                </a>
                            <?php endif; ?>
                        <?php endfor; ?>

                        <?php if ($pagina < $numeroPagine): ?>
                            <a
                                class="pagination-link pagination-arrow"
                                href="<?= htmlspecialchars(creaLinkPagina($pagina + 1, $filtriCorrenti), ENT_QUOTES, 'UTF-8') ?>"
                            >
                                Successiva &rarr;
                            </a>
                        <?php else: ?>
                            <span class="pagination-disabled pagination-arrow">Successiva &rarr;</span>
                        <?php endif; ?>

                    </div>

                </nav>

            <?php endif; ?>

        <?php endif; ?>

    </section>

    <!-- Menu laterale destro -->
    <?php require_once __DIR__ . '/../includes/nav.php'; ?>

</main>

<!-- Footer -->
<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<!-- Gestisce lo scroll automatico ai bordi della tabella -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    const wrap = document.getElementById('tabellaPrenotazioniWrap');
    if (!wrap) {
        return;
    }

    const area = wrap.closest('.tabella-scroll-area');
    const leftEdge = area.querySelector('.scroll-edge-left');
    const rightEdge = area.querySelector('.scroll-edge-right');

    if (!leftEdge || !rightEdge) {
        return;
    }

    let animationId = null;
    let direction = 0;
    const speed = 10;

    function maxScrollLeft() {
        return wrap.scrollWidth - wrap.clientWidth;
    }

    function updateEdges() {
        const max = maxScrollLeft();
        const current = wrap.scrollLeft;

        if (max <= 0) {
            leftEdge.classList.add('is-hidden');
            rightEdge.classList.add('is-hidden');
            stopAutoScroll();
            return;
        }

        leftEdge.classList.toggle('is-hidden', current <= 1);
        rightEdge.classList.toggle('is-hidden', current >= max - 1);
    }

    function stepScroll() {
        if (direction === 0) {
            animationId = null;
            return;
        }
        wrap.scrollLeft += direction * speed;
        updateEdges();
        animationId = requestAnimationFrame(stepScroll);
    }

    function startAutoScroll(newDirection, edgeElement) {
        direction = newDirection;
        leftEdge.classList.remove('is-active');
        rightEdge.classList.remove('is-active');
        if (edgeElement) {
            edgeElement.classList.add('is-active');
        }
        if (animationId === null) {
            animationId = requestAnimationFrame(stepScroll);
        }
    }

    function stopAutoScroll() {
        direction = 0;
        leftEdge.classList.remove('is-active');
        rightEdge.classList.remove('is-active');
        if (animationId !== null) {
            cancelAnimationFrame(animationId);
            animationId = null;
        }
    }

    leftEdge.addEventListener('mouseenter', function () {
        startAutoScroll(-1, leftEdge);
    });
    rightEdge.addEventListener('mouseenter', function () {
        startAutoScroll(1, rightEdge);
    });
    leftEdge.addEventListener('mouseleave', stopAutoScroll);
    rightEdge.addEventListener('mouseleave', stopAutoScroll);
    wrap.addEventListener('mouseleave', stopAutoScroll);

    wrap.addEventListener('scroll', updateEdges);
    window.addEventListener('resize', updateEdges);

    updateEdges();
});
</script>

</body>
</html>