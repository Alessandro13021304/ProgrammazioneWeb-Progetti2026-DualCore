<?php

// Connessione al database della palestra
// Le pagine del sito includono questo file per usare la variabile $pdo

$host = "localhost";
$dbname = "my_dualcorepalestra";
$user = "dualcorepalestra";
$pass = "123456789";

try {
    // Crea la connessione PDO al database MySQL
    $pdo = new PDO(
        "mysql:host={$host};dbname={$dbname};charset=utf8",
        $user,
        $pass
    );

    // Genera un'eccezione quando si verifica un errore SQL
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Restituisce le query come array associativi
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Restituisce errore interno del server se la connessione fallisce
    http_response_code(500);

    // Mostra un messaggio generico senza esporre i dettagli del database
    echo "<!DOCTYPE html><html lang='it'><head><meta charset='UTF-8'>";
    echo "<title>Errore</title></head><body>";
    echo "<p style='font-family:Arial;color:#b33636;padding:2rem;'>";
    echo "Impossibile collegarsi al database. Riprovare più tardi.";
    echo "</p></body></html>";

    exit;
}