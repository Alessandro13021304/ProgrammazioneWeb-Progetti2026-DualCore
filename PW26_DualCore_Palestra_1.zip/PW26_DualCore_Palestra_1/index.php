<?php

// Si va direttamente sui Clienti
header('Location: pages/clienti.php');
exit;